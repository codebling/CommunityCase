package net.sourceforge.clearcase.simple;

import net.sourceforge.clearcase.comapi.Application;
import net.sourceforge.clearcase.comapi.CCKeepState;
import net.sourceforge.clearcase.comapi.CCReservedState;
import net.sourceforge.clearcase.comapi.CCVersionToCheckOut;
import net.sourceforge.clearcase.comapi.ClearTool;
import net.sourceforge.clearcase.comapi.ICCCheckedOutFile;
import net.sourceforge.clearcase.comapi.ICCElement;
import net.sourceforge.clearcase.comapi.ICCVersion;
import net.sourceforge.clearcase.comapi.ICCView;
import net.sourceforge.clearcase.comapi.IClearCase;
import net.sourceforge.clearcase.comapi.IClearTool;

import com.jacob.com.Variant;

public class ClearcaseJNI implements IClearcase
{

	ClearcaseJNI()
	{
	}

	// synchronize all access in the hopes it fixes JVM crashes
	public synchronized void destroy()
	{
	}

	/**
	 * @see net.sourceforge.eclipseccase.IClearcase#add(String, String, boolean)
	 */
	public synchronized Status add(String file, String comment, boolean isdirectory)
	{
		Status result;
		try
		{
			IClearCase ccase = new Application();
			if (isdirectory)
			{
				ICCCheckedOutFile cofile = ccase.createElement(file, comment, false, new Variant("directory"));
			}
			else
			{
				ICCCheckedOutFile cofile = ccase.createElement(file, comment, false);
			}
			result = new Status(true, "Add Successful");
		}
		catch (Exception ex)
		{
			result = new Status(false, ex.getMessage());
		}
		return result;
	}

	/**
	 * @see net.sourceforge.eclipseccase.IClearcase#checkin(String, String, boolean)
	 */
	public synchronized Status checkin(String file, String comment, boolean ptime)
	{
		Status result;
		try
		{
			if (ptime)
			{
				result = cleartool("checkin -identical -ptime -c " + ClearcaseUtil.quote(comment) + " " + ClearcaseUtil.quote(file));
				if (result.status)
					result.message = "Checkin Successful";
			}
			else
			{
				IClearCase ccase = new Application();
				ICCVersion version = ccase.getVersion(new Variant(file));
				ICCCheckedOutFile cofile = ccase.getCheckedOutFile(file);
				cofile.checkIn(comment, true, "", CCKeepState.ccRemove);
				result = new Status(true, "Checkin Successful");
			}
		}
		catch (Exception ex)
		{
			result = new Status(false, ex.getMessage());
		}
		return result;
	}

	/**
	 * @see net.sourceforge.eclipseccase.IClearcase#checkout(String, String, boolean, boolean)
	 */
	public synchronized Status checkout(
		String file,
		String comment,
		boolean reserved,
		boolean ptime)
	{
		Status result;
		try
		{
			IClearCase ccase = new Application();
			ICCVersion version = ccase.getVersion(new Variant(file));
			boolean useHijacked = false;
			boolean mustBeLatest = false;
			ICCCheckedOutFile cofile =
				version.checkOut(
					reserved
						? CCReservedState.ccReserved
						: CCReservedState.ccUnreserved,
					comment,
					useHijacked,
					CCVersionToCheckOut.ccVersion_Default,
					mustBeLatest,
					ptime);
			result = new Status(true, "Checkout Successful");
		}
		catch (Exception ex)
		{
			result = new Status(false, ex.getMessage());
		}
		return result;
	}

	/**
	 * @see net.sourceforge.eclipseccase.IClearcase#cleartool(String)
	 */
	public synchronized Status cleartool(String cmd)
	{
		Status result;
		try
		{
			
			IClearTool cleartool = new ClearTool();
			String output = cleartool.cmdExec(cmd);
			if (output == null)
				output = "";
			result = new Status(true, output);
		}
		catch (Exception ex)
		{
			result = new Status(false, ex.getMessage());
		}
		return result;
	}

	/**
	 * @see net.sourceforge.eclipseccase.IClearcase#delete(String, String)
	 */
	public synchronized Status delete(String file, String comment)
	{
		Status result;
		try
		{
			
			IClearCase ccase = new Application();
			ICCVersion version = ccase.getVersion(new Variant(file));
			ICCElement element = version.getElement();
			element.removeName(comment, true);
			result = new Status(true, "Delete Successful");
		}
		catch (Exception ex)
		{
			result = new Status(false, ex.getMessage());
		}
		return result;
	}

	/**
	 * @see net.sourceforge.eclipseccase.IClearcase#getViewName(String)
	 */
	public synchronized Status getViewName(String file)
	{
		Status result;
		try
		{
			
			IClearCase ccase = new Application();
			ICCView view = ccase.getView(file);
			result = new Status(true, view.getTagName());
		}
		catch (Exception ex)
		{
			result = new Status(false, ex.getMessage());
		}
		return result;
	}

	/**
	 * @see net.sourceforge.eclipseccase.IClearcase#isCheckedOut(String)
	 */
	public synchronized boolean isCheckedOut(String file)
	{
		boolean result;
		try
		{
			
			IClearCase ccase = new Application();
			ICCVersion version = ccase.getVersion(new Variant(file));
			result = version.getIsCheckedOut();
		}
		catch (Exception ex)
		{
			throw new RuntimeException(ex.getMessage());
		}
		return result;
	}

	/**
	 * @see net.sourceforge.eclipseccase.IClearcase#isDifferent(String)
	 */
	public synchronized boolean isDifferent(String file)
	{
		boolean result;
		try
		{
			
			IClearCase ccase = new Application();
			ICCVersion version = ccase.getVersion(new Variant(file));
			result = version.getIsDifferent();
		}
		catch (Exception ex)
		{
			throw new RuntimeException(ex.getMessage());
		}
		return result;
	}

	/**
	 * @see net.sourceforge.eclipseccase.IClearcase#isElement(String)
	 */
	public synchronized boolean isElement(String file)
	{
		boolean result = false;
		try
		{
			
			IClearCase ccase = new Application();
			ICCVersion version = ccase.getVersion(new Variant(file));
			result = true;
		}
		catch (Exception ex)
		{
		}
		return result;
	}

	/**
	 * @see net.sourceforge.eclipseccase.IClearcase#isHijacked(String)
	 */
	public synchronized boolean isHijacked(String file)
	{
		boolean result = false;
		try
		{
			
			IClearCase ccase = new Application();
			ICCVersion version = ccase.getVersion(new Variant(file));
			result = version.getIsHijacked();
		}
		catch (Exception ex)
		{
		}
		return result;
	}

	/**
	 * @see net.sourceforge.eclipseccase.IClearcase#isSnapShot(String)
	 */
	public synchronized boolean isSnapShot(String file)
	{
		boolean result = false;
		try
		{
			
			IClearCase ccase = new Application();
			ICCView view = ccase.getView(file);
			result = view.getIsSnapShot();
		}
		catch (Exception ex)
		{
		}
		return result;
	}

	/**
	 * @see net.sourceforge.eclipseccase.IClearcase#move(String, String, String)
	 */
	public synchronized Status move(String file, String newfile, String comment)
	{
		Status result;
		try
		{
			
			IClearCase ccase = new Application();
			ICCElement element = ccase.getElement(file);
			element.rename(newfile, comment);
			result = new Status(true, "Move Successful");
		}
		catch (Exception ex)
		{
			result = new Status(false, ex.getMessage());
		}
		return result;
	}

	/**
	 * @see net.sourceforge.eclipseccase.IClearcase#uncheckout(String, boolean)
	 */
	public synchronized Status uncheckout(String file, boolean keep)
	{
		Status result;
		try
		{
			
			IClearCase ccase = new Application();
			ICCCheckedOutFile cofile = ccase.getCheckedOutFile(file);
			cofile.unCheckOut(keep ? CCKeepState.ccKeep : CCKeepState.ccRemove);
			result = new Status(true, "Uncheckout Successful");
		}
		catch (Exception ex)
		{
			result = new Status(false, ex.getMessage());
		}
		return result;
	}

}