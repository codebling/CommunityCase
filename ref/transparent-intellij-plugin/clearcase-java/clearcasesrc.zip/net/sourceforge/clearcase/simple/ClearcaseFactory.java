package net.sourceforge.clearcase.simple;



/**
 * The singleton factory class for genrating a IClearcase implementation.
 */
public class ClearcaseFactory
{
	private static boolean isWindows = System.getProperty("os.name").toLowerCase().indexOf("windows") != -1;
	private static ClearcaseFactory instance = new ClearcaseFactory();

	public static final int DUMMY = 0;
	public static final int CLI = 1;
	public static final int JNI = 2;
	
	private IClearcase defaultImpl;
	
	private ClearcaseFactory()
	{
	}
	
	
	/**
	 * Returns the singleton instance of the factory.
	 * 
	 * @return ClearcaseFactory
	 */
	public static ClearcaseFactory getInstance()
	{
		return instance;
	}
	
	
	/**
	 * Returns the default implemntation of clearcase ofr the platform.  If the System property
	 * "clearcase.dummy" is set, a dummy implemntation is returned that can be used without
	 * clearcase present (for development/testing on home machines that might not have clearcase)
	 * 
	 * @return IClearcase
	 */
	public synchronized IClearcase getDefault() throws ClearcaseException
	{
		if (defaultImpl == null)
		{
			boolean isDummy = Boolean.valueOf(System.getProperty("clearcase.dummy")).booleanValue();
			if (isDummy)
			{
				defaultImpl = createInstance(DUMMY);
			}
			else
			{
				if (isWindows)
					defaultImpl = createInstance(JNI);
				else
					defaultImpl = createInstance(CLI); 
			}
		}
		return defaultImpl;
	}

	/**
	 * Returns an implemntation of the given type.
	 * @param type The implementation type to construct - must be of a type known to the factory
	 * @return IClearcase
	 */
	public IClearcase createInstance(int type) throws ClearcaseException
	{
		IClearcase result = null;
		try
		{
			switch(type)
			{
				case DUMMY:
					result = new ClearcaseDummy();
					break;
				case CLI:
					result = new ClearcaseCLI();
					break;
				case JNI:
					result = new ClearcaseJNI();
					break;
				default:
					throw new ClearcaseException("Unknown IClearcase implementation type");
			}
		}
		catch (ClearcaseException e)
		{
			throw e;
		}
		catch (Throwable t)
		{
			throw new ClearcaseException("Could not instantiate a valid clearcase instance due to: " + t);
		}
		return result;			
	}
}
