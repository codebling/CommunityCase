/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

public class ICCCheckedOutFiles extends Dispatch {

	public static final String componentName = "ClearCase.ICCCheckedOutFiles";

	public ICCCheckedOutFiles() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public ICCCheckedOutFiles(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public ICCCheckedOutFiles(String compName) {
		super(compName);
	}

	public ICCCheckedOutFile getItem(int lastParam) {
		return new ICCCheckedOutFile(Dispatch.call(this, "Item", new Variant(lastParam)).toDispatch());
	}

	public void add(ICCCheckedOutFile lastParam) {
		Dispatch.call(this, "Add", lastParam);
	}

	public int getCount() {
		return Dispatch.get(this, "Count").toInt();
	}

	public void remove(int lastParam) {
		Dispatch.call(this, "Remove", new Variant(lastParam));
	}

	public Object get_NewEnum() {
		return Dispatch.get(this, "_NewEnum");
	}

}
