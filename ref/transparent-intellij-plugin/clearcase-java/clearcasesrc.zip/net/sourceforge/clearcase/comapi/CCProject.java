/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCProject extends ICCProject {

	public static final String componentName = "ClearCase.CCProject";

	public CCProject() {
		super(componentName);
	}

	public CCProject(Dispatch d) {
		super(d);
	}
}
