/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;


public interface CCPath_Selection {

	public static final int ccSelection_Path = 0;
	public static final int ccSelection_SubTreeRoot = 1;
	public static final int ccSelection_Directory = 2;
	public static final int ccSelection_AllInVOB = 3;
	public static final int ccSelection_AllVOBs = 4;
}
