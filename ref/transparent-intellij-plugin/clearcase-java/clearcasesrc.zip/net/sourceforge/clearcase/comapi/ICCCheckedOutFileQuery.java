/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

public class ICCCheckedOutFileQuery extends Dispatch {

	public static final String componentName = "ClearCase.ICCCheckedOutFileQuery";

	public ICCCheckedOutFileQuery() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public ICCCheckedOutFileQuery(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public ICCCheckedOutFileQuery(String compName) {
		super(compName);
	}

	public ICCCheckedOutFiles apply() {
		return new ICCCheckedOutFiles(Dispatch.call(this, "Apply").toDispatch());
	}

	public String getBranchType() {
		return Dispatch.get(this, "BranchType").toString();
	}

	public void setBranchType(String lastParam) {
		Dispatch.put(this, "BranchType", lastParam);
	}

	public boolean getExamineAllReplicas() {
		return Dispatch.get(this, "ExamineAllReplicas").toBoolean();
	}

	public void setExamineAllReplicas(boolean lastParam) {
		Dispatch.put(this, "ExamineAllReplicas", new Variant(lastParam));
	}

	public Variant getPathArray() {
		return Dispatch.get(this, "PathArray");
	}

	public void setPathArray(Variant lastParam) {
		Dispatch.put(this, "PathArray", lastParam);
	}

	public int getPathSelects() {
		return Dispatch.get(this, "PathSelects").toInt();
	}

	public void setPathSelects(int lastParam) {
		Dispatch.put(this, "PathSelects", new Variant(lastParam));
	}

	public boolean getUseCurrentView() {
		return Dispatch.get(this, "UseCurrentView").toBoolean();
	}

	public void setUseCurrentView(boolean lastParam) {
		Dispatch.put(this, "UseCurrentView", new Variant(lastParam));
	}

	public String getUser() {
		return Dispatch.get(this, "User").toString();
	}

	public void setUser(String lastParam) {
		Dispatch.put(this, "User", lastParam);
	}

}
