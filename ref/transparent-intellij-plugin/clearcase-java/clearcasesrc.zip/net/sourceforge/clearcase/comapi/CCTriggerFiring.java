/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;


public interface CCTriggerFiring {

	public static final int ccFiring_PreOp = 1;
	public static final int ccFiring_PostOp = 2;
}
