/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;


public interface CCKindOfTrigger {

	public static final int ccKind_Type = 0;
	public static final int ccKind_Element = 1;
	public static final int ccKind_AllElement = 2;
}
