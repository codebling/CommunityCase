/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;


public interface CCTriggerOperationKind {

	public static final int ccOp_mktype = 5;
	public static final int ccOp_rmtype = 6;
	public static final int ccOp_rntype = 7;
	public static final int ccOp_lock = 8;
	public static final int ccOp_unlock = 9;
	public static final int ccOp_checkout = 10;
	public static final int ccOp_mkelem = 11;
	public static final int ccOp_mkbranch = 12;
	public static final int ccOp_checkin = 13;
	public static final int ccOp_rmelem = 14;
	public static final int ccOp_rmbranch = 15;
	public static final int ccOp_rmver = 16;
	public static final int ccOp_rmname = 17;
	public static final int ccOp_chtype = 18;
	public static final int ccOp_mklabel = 19;
	public static final int ccOp_mkattr = 20;
	public static final int ccOp_mkhlink = 21;
	public static final int ccOp_mktrigger = 22;
	public static final int ccOp_rmlabel = 23;
	public static final int ccOp_rmattr = 24;
	public static final int ccOp_rmhlink = 25;
	public static final int ccOp_rmtrigger = 26;
	public static final int ccOp_uncheckout = 27;
	public static final int ccOp_lnname = 32;
	public static final int ccOp_mkslink = 33;
	public static final int ccOp_reserve = 37;
	public static final int ccOp_unreserve = 41;
	public static final int ccOp_chevent = 44;
	public static final int ccOp_chmaster = 49;
}
