/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCLabel extends ICCLabel {

	public static final String componentName = "ClearCase.CCLabel";

	public CCLabel() {
		super(componentName);
	}

	public CCLabel(Dispatch d) {
		super(d);
	}
}
