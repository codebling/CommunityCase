/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCActivity extends ICCActivity {

	public static final String componentName = "ClearCase.CCActivity";

	public CCActivity() {
		super(componentName);
	}

	public CCActivity(Dispatch d) {
		super(d);
	}
}
