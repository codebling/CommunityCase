/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCTriggers extends ICCTriggers {

	public static final String componentName = "ClearCase.CCTriggers";

	public CCTriggers() {
		super(componentName);
	}

	public CCTriggers(Dispatch d) {
		super(d);
	}
}
