/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class ICCBaselineComparison extends Dispatch {

	public static final String componentName = "ClearCase.ICCBaselineComparison";

	public ICCBaselineComparison() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public ICCBaselineComparison(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public ICCBaselineComparison(String compName) {
		super(compName);
	}

	public ICCActivities getActivitiesInOneButNotTwo() {
		return new ICCActivities(Dispatch.get(this, "ActivitiesInOneButNotTwo").toDispatch());
	}

	public ICCActivities getActivitiesInTwoButNotOne() {
		return new ICCActivities(Dispatch.get(this, "ActivitiesInTwoButNotOne").toDispatch());
	}

	public ICCBaseline getBaselineOne() {
		return new ICCBaseline(Dispatch.get(this, "BaselineOne").toDispatch());
	}

	public void setBaselineOne(ICCBaseline lastParam) {
		Dispatch.put(this, "BaselineOne", lastParam);
	}

	public ICCBaseline getBaselineTwo() {
		return new ICCBaseline(Dispatch.get(this, "BaselineTwo").toDispatch());
	}

	public void setBaselineTwo(ICCBaseline lastParam) {
		Dispatch.put(this, "BaselineTwo", lastParam);
	}

	public ICCActivities getChangedActivities() {
		return new ICCActivities(Dispatch.get(this, "ChangedActivities").toDispatch());
	}

	public void compare() {
		Dispatch.call(this, "Compare");
	}

	public ICCStream getStreamOne() {
		return new ICCStream(Dispatch.get(this, "StreamOne").toDispatch());
	}

	public void setStreamOne(ICCStream lastParam) {
		Dispatch.put(this, "StreamOne", lastParam);
	}

	public ICCStream getStreamTwo() {
		return new ICCStream(Dispatch.get(this, "StreamTwo").toDispatch());
	}

	public void setStreamTwo(ICCStream lastParam) {
		Dispatch.put(this, "StreamTwo", lastParam);
	}

	public ICCVersions getVersionsInOneButNotTwo() {
		return new ICCVersions(Dispatch.get(this, "VersionsInOneButNotTwo").toDispatch());
	}

	public ICCVersions getVersionsInTwoButNotOne() {
		return new ICCVersions(Dispatch.get(this, "VersionsInTwoButNotOne").toDispatch());
	}

}
