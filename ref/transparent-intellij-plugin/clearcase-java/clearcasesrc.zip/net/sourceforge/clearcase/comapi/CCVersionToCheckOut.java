/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;


public interface CCVersionToCheckOut {

	public static final int ccVersion_Default = 0;
	public static final int ccVersion_SpecificVersion = 1;
}
