/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

public class ICCProjectPolicy extends Dispatch {

	public static final String componentName = "ClearCase.ICCProjectPolicy";

	public ICCProjectPolicy() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public ICCProjectPolicy(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public ICCProjectPolicy(String compName) {
		super(compName);
	}

	public boolean getDeliverRequireCheckin() {
		return Dispatch.get(this, "DeliverRequireCheckin").toBoolean();
	}

	public void setDeliverRequireCheckin(boolean lastParam) {
		Dispatch.put(this, "DeliverRequireCheckin", new Variant(lastParam));
	}

	public boolean getDeliverRequireRebase() {
		return Dispatch.get(this, "DeliverRequireRebase").toBoolean();
	}

	public void setDeliverRequireRebase(boolean lastParam) {
		Dispatch.put(this, "DeliverRequireRebase", new Variant(lastParam));
	}

	public boolean getUNIXDevelopmentSnapshot() {
		return Dispatch.get(this, "UNIXDevelopmentSnapshot").toBoolean();
	}

	public void setUNIXDevelopmentSnapshot(boolean lastParam) {
		Dispatch.put(this, "UNIXDevelopmentSnapshot", new Variant(lastParam));
	}

	public boolean getUNIXIntegrationSnapshot() {
		return Dispatch.get(this, "UNIXIntegrationSnapshot").toBoolean();
	}

	public void setUNIXIntegrationSnapshot(boolean lastParam) {
		Dispatch.put(this, "UNIXIntegrationSnapshot", new Variant(lastParam));
	}

	public boolean getWinDevelopmentSnapshot() {
		return Dispatch.get(this, "WinDevelopmentSnapshot").toBoolean();
	}

	public void setWinDevelopmentSnapshot(boolean lastParam) {
		Dispatch.put(this, "WinDevelopmentSnapshot", new Variant(lastParam));
	}

	public boolean getWinIntegrationSnapshot() {
		return Dispatch.get(this, "WinIntegrationSnapshot").toBoolean();
	}

	public void setWinIntegrationSnapshot(boolean lastParam) {
		Dispatch.put(this, "WinIntegrationSnapshot", new Variant(lastParam));
	}

}
