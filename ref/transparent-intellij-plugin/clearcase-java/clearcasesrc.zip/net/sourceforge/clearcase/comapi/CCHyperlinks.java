/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCHyperlinks extends ICCHyperlinks {

	public static final String componentName = "ClearCase.CCHyperlinks";

	public CCHyperlinks() {
		super(componentName);
	}

	public CCHyperlinks(Dispatch d) {
		super(d);
	}
}
