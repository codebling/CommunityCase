/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class ICCLabel extends Dispatch {

	public static final String componentName = "ClearCase.ICCLabel";

	public ICCLabel() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public ICCLabel(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public ICCLabel(String compName) {
		super(compName);
	}

	public void remove(String lastParam) {
		Dispatch.call(this, "Remove", lastParam);
	}

	public void remove() {
		Dispatch.call(this, "Remove");
	}

	public ICCLabelType getType() {
		return new ICCLabelType(Dispatch.get(this, "Type").toDispatch());
	}

	public ICCVOB getVOB() {
		return new ICCVOB(Dispatch.get(this, "VOB").toDispatch());
	}

}
