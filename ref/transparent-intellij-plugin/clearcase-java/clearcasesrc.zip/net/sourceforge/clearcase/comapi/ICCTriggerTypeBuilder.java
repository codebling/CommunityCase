/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

public class ICCTriggerTypeBuilder extends Dispatch {

	public static final String componentName = "ClearCase.ICCTriggerTypeBuilder";

	public ICCTriggerTypeBuilder() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public ICCTriggerTypeBuilder(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public ICCTriggerTypeBuilder(String compName) {
		super(compName);
	}

	public String getName() {
		return Dispatch.get(this, "Name").toString();
	}

	public void setName(String lastParam) {
		Dispatch.put(this, "Name", lastParam);
	}

	public Variant getActionsArray() {
		return Dispatch.get(this, "ActionsArray");
	}

	public void addExecAction(String lastParam) {
		Dispatch.call(this, "AddExecAction", lastParam);
	}

	public void addExecUNIXAction(String lastParam) {
		Dispatch.call(this, "AddExecUNIXAction", lastParam);
	}

	public void addExecWinAction(String lastParam) {
		Dispatch.call(this, "AddExecWinAction", lastParam);
	}

	public void addMkattrAction(ICCAttributeType pAttributeType, Variant lastParam) {
		Dispatch.call(this, "AddMkattrAction", pAttributeType, lastParam);
	}

	public void addMkhlinkFromAction(ICCHyperlinkType pHyperlinkType, String lastParam) {
		Dispatch.call(this, "AddMkhlinkFromAction", pHyperlinkType, lastParam);
	}

	public void addMkhlinkToAction(ICCHyperlinkType pHyperlinkType, String lastParam) {
		Dispatch.call(this, "AddMkhlinkToAction", pHyperlinkType, lastParam);
	}

	public void addMklabelAction(ICCLabelType lastParam) {
		Dispatch.call(this, "AddMklabelAction", lastParam);
	}

	public ICCTriggerType create(String lastParam) {
		return new ICCTriggerType(Dispatch.call(this, "Create", lastParam).toDispatch());
	}

	public ICCTriggerType create() {
		return new ICCTriggerType(Dispatch.call(this, "Create").toDispatch());
	}

	public boolean getDebugPrinting() {
		return Dispatch.get(this, "DebugPrinting").toBoolean();
	}

	public void setDebugPrinting(boolean lastParam) {
		Dispatch.put(this, "DebugPrinting", new Variant(lastParam));
	}

	public Variant getExemptUsersStringArray() {
		return Dispatch.get(this, "ExemptUsersStringArray");
	}

	public void setExemptUsersStringArray(Variant lastParam) {
		Dispatch.put(this, "ExemptUsersStringArray", lastParam);
	}

	public void fireOn(int lastParam) {
		Dispatch.call(this, "FireOn", new Variant(lastParam));
	}

	public int getFiring() {
		return Dispatch.get(this, "Firing").toInt();
	}

	public void setFiring(int lastParam) {
		Dispatch.put(this, "Firing", new Variant(lastParam));
	}

	public void includeOn(Variant lastParam) {
		Dispatch.call(this, "IncludeOn", lastParam);
	}

	public Variant getInclusionsArray() {
		return Dispatch.get(this, "InclusionsArray");
	}

	public int getKindOfTrigger() {
		return Dispatch.get(this, "KindOfTrigger").toInt();
	}

	public void setKindOfTrigger(int lastParam) {
		Dispatch.put(this, "KindOfTrigger", new Variant(lastParam));
	}

	public int getNumberOfActions() {
		return Dispatch.get(this, "NumberOfActions").toInt();
	}

	public int getNumberOfExemptUsers() {
		return Dispatch.get(this, "NumberOfExemptUsers").toInt();
	}

	public int getNumberOfInclusions() {
		return Dispatch.get(this, "NumberOfInclusions").toInt();
	}

	public int getNumberOfOperationKinds() {
		return Dispatch.get(this, "NumberOfOperationKinds").toInt();
	}

	public int getNumberOfRestrictions() {
		return Dispatch.get(this, "NumberOfRestrictions").toInt();
	}

	public Variant getOperationKindsArray() {
		return Dispatch.get(this, "OperationKindsArray");
	}

	public void removeAction(int lastParam) {
		Dispatch.call(this, "RemoveAction", new Variant(lastParam));
	}

	public void removeInclusion(Variant lastParam) {
		Dispatch.call(this, "RemoveInclusion", lastParam);
	}

	public void removeOperationKind(int lastParam) {
		Dispatch.call(this, "RemoveOperationKind", new Variant(lastParam));
	}

	public void removeRestriction(Variant lastParam) {
		Dispatch.call(this, "RemoveRestriction", lastParam);
	}

	public ICCTriggerType replace(String lastParam) {
		return new ICCTriggerType(Dispatch.call(this, "Replace", lastParam).toDispatch());
	}

	public ICCTriggerType replace() {
		return new ICCTriggerType(Dispatch.call(this, "Replace").toDispatch());
	}

	public void restrictBy(Variant lastParam) {
		Dispatch.call(this, "RestrictBy", lastParam);
	}

	public Variant getRestrictionsArray() {
		return Dispatch.get(this, "RestrictionsArray");
	}

	public ICCVOB getVOB() {
		return new ICCVOB(Dispatch.get(this, "VOB").toDispatch());
	}

}
