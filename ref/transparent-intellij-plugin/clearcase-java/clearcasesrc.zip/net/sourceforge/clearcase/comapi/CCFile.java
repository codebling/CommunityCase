/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCFile extends ICCFile {

	public static final String componentName = "ClearCase.CCFile";

	public CCFile() {
		super(componentName);
	}

	public CCFile(Dispatch d) {
		super(d);
	}
}
