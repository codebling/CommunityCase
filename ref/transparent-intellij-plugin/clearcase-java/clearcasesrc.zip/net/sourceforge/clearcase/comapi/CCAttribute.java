/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCAttribute extends ICCAttribute {

	public static final String componentName = "ClearCase.CCAttribute";

	public CCAttribute() {
		super(componentName);
	}

	public CCAttribute(Dispatch d) {
		super(d);
	}
}
