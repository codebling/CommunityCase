/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;


public interface CCTriggerTypesAll {

	public static final int ccAll_ElementTypes = 13;
	public static final int ccAll_BranchTypes = 14;
	public static final int ccAll_AttributeTypes = 15;
	public static final int ccAll_HyperlinkTypes = 16;
	public static final int ccAll_TriggerTypes = 17;
	public static final int ccAll_LabelTypes = 20;
}
