/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCProjects extends ICCProjects {

	public static final String componentName = "ClearCase.CCProjects";

	public CCProjects() {
		super(componentName);
	}

	public CCProjects(Dispatch d) {
		super(d);
	}
}
