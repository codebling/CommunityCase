/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;


public interface CCTypeScope {

	public static final int ccScope_Ordinary = 0;
	public static final int ccScope_LocalCopy = 1;
	public static final int ccScope_Global = 2;
}
