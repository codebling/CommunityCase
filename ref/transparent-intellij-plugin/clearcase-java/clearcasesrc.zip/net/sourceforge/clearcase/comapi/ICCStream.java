/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

public class ICCStream extends Dispatch {

	public static final String componentName = "ClearCase.ICCStream";

	public ICCStream() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public ICCStream(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public ICCStream(String compName) {
		super(compName);
	}

	public ICCAttribute getAttribute(String lastParam) {
		return new ICCAttribute(Dispatch.call(this, "Attribute", lastParam).toDispatch());
	}

	public ICCAttributes getAttributes() {
		return new ICCAttributes(Dispatch.get(this, "Attributes").toDispatch());
	}

	public String getComment() {
		return Dispatch.get(this, "Comment").toString();
	}

	public void setComment(String lastParam) {
		Dispatch.put(this, "Comment", lastParam);
	}

	public ICCHistoryRecord getCreationRecord() {
		return new ICCHistoryRecord(Dispatch.get(this, "CreationRecord").toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor, boolean excludeCheckOutEvents, boolean recurse, boolean lastParam) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor), new Variant(excludeCheckOutEvents), new Variant(recurse), new Variant(lastParam)).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor, boolean excludeCheckOutEvents, boolean recurse) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor), new Variant(excludeCheckOutEvents), new Variant(recurse)).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor, boolean excludeCheckOutEvents) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor), new Variant(excludeCheckOutEvents)).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor)).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since)).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType).toDispatch());
	}

	public ICCHyperlinks getHyperlinks(String lastParam) {
		return new ICCHyperlinks(Dispatch.call(this, "Hyperlinks", lastParam).toDispatch());
	}

	public ICCHyperlinks getHyperlinks() {
		return new ICCHyperlinks(Dispatch.get(this, "Hyperlinks").toDispatch());
	}

	public String getOID() {
		return Dispatch.get(this, "OID").toString();
	}

	public String getVOBFamilyUUID() {
		return Dispatch.get(this, "VOBFamilyUUID").toString();
	}

	public String getName() {
		return Dispatch.get(this, "Name").toString();
	}

	public void createLock(String comment, boolean obsolete, Variant lastParam) {
		Dispatch.call(this, "CreateLock", comment, new Variant(obsolete), lastParam);
	}

	public void createLock(String comment, boolean obsolete) {
		Dispatch.call(this, "CreateLock", comment, new Variant(obsolete));
	}

	public void createLock(String comment) {
		Dispatch.call(this, "CreateLock", comment);
	}

	public void createLock() {
		Dispatch.call(this, "CreateLock");
	}

	public String getGroup() {
		return Dispatch.get(this, "Group").toString();
	}

	public ICCLock getLock() {
		return new ICCLock(Dispatch.get(this, "Lock").toDispatch());
	}

	public String getMaster() {
		return Dispatch.get(this, "Master").toString();
	}

	public String getOwner() {
		return Dispatch.get(this, "Owner").toString();
	}

	public ICCProjectVOB getProjectVOB() {
		return new ICCProjectVOB(Dispatch.get(this, "ProjectVOB").toDispatch());
	}

	public void setGroup(String newGroup, String lastParam) {
		Dispatch.call(this, "SetGroup", newGroup, lastParam);
	}

	public void setGroup(String newGroup) {
		Dispatch.call(this, "SetGroup", newGroup);
	}

	public void setMaster(String replica, String lastParam) {
		Dispatch.call(this, "SetMaster", replica, lastParam);
	}

	public void setMaster(String replica) {
		Dispatch.call(this, "SetMaster", replica);
	}

	public void setOwner(String newOwner, String lastParam) {
		Dispatch.call(this, "SetOwner", newOwner, lastParam);
	}

	public void setOwner(String newOwner) {
		Dispatch.call(this, "SetOwner", newOwner);
	}

	public String getTitle() {
		return Dispatch.get(this, "Title").toString();
	}

	public ICCActivities getActivities() {
		return new ICCActivities(Dispatch.get(this, "Activities").toDispatch());
	}

	public ICCBaselines getBaselines(ICCComponent lastParam) {
		return new ICCBaselines(Dispatch.call(this, "Baselines", lastParam).toDispatch());
	}

	public ICCActivity createActivity(String headline, String comment, String lastParam) {
		return new ICCActivity(Dispatch.call(this, "CreateActivity", headline, comment, lastParam).toDispatch());
	}

	public ICCActivity createActivity(String headline, String comment) {
		return new ICCActivity(Dispatch.call(this, "CreateActivity", headline, comment).toDispatch());
	}

	public ICCActivity createActivity(String headline) {
		return new ICCActivity(Dispatch.call(this, "CreateActivity", headline).toDispatch());
	}

	public ICCActivity createActivity() {
		return new ICCActivity(Dispatch.call(this, "CreateActivity").toDispatch());
	}

	public ICCBaseline getFoundationBaseline(ICCComponent lastParam) {
		return new ICCBaseline(Dispatch.call(this, "FoundationBaseline", lastParam).toDispatch());
	}

	public ICCBaselines getFoundationBaselines() {
		return new ICCBaselines(Dispatch.get(this, "FoundationBaselines").toDispatch());
	}

	public boolean getHasActivities() {
		return Dispatch.get(this, "HasActivities").toBoolean();
	}

	public boolean getIsIntegrationStream() {
		return Dispatch.get(this, "IsIntegrationStream").toBoolean();
	}

	public ICCBaseline getLatestBaseline(ICCComponent lastParam) {
		return new ICCBaseline(Dispatch.call(this, "LatestBaseline", lastParam).toDispatch());
	}

	public ICCBaselines getLatestBaselines() {
		return new ICCBaselines(Dispatch.get(this, "LatestBaselines").toDispatch());
	}

	public ICCProject getProject() {
		return new ICCProject(Dispatch.get(this, "Project").toDispatch());
	}

	public ICCViews getViews(String lastParam) {
		return new ICCViews(Dispatch.call(this, "Views", lastParam).toDispatch());
	}

	public ICCViews getViews() {
		return new ICCViews(Dispatch.get(this, "Views").toDispatch());
	}

}
