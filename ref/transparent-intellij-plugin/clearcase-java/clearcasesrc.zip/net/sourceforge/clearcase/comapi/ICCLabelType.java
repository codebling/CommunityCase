/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

public class ICCLabelType extends Dispatch {

	public static final String componentName = "ClearCase.ICCLabelType";

	public ICCLabelType() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public ICCLabelType(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public ICCLabelType(String compName) {
		super(compName);
	}

	public ICCAttribute getAttribute(String lastParam) {
		return new ICCAttribute(Dispatch.call(this, "Attribute", lastParam).toDispatch());
	}

	public ICCAttributes getAttributes() {
		return new ICCAttributes(Dispatch.get(this, "Attributes").toDispatch());
	}

	public String getComment() {
		return Dispatch.get(this, "Comment").toString();
	}

	public void setComment(String lastParam) {
		Dispatch.put(this, "Comment", lastParam);
	}

	public ICCHistoryRecord getCreationRecord() {
		return new ICCHistoryRecord(Dispatch.get(this, "CreationRecord").toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor, boolean excludeCheckOutEvents, boolean recurse, boolean lastParam) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor), new Variant(excludeCheckOutEvents), new Variant(recurse), new Variant(lastParam)).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor, boolean excludeCheckOutEvents, boolean recurse) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor), new Variant(excludeCheckOutEvents), new Variant(recurse)).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor, boolean excludeCheckOutEvents) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor), new Variant(excludeCheckOutEvents)).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor)).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since)).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType).toDispatch());
	}

	public ICCHyperlinks getHyperlinks(String lastParam) {
		return new ICCHyperlinks(Dispatch.call(this, "Hyperlinks", lastParam).toDispatch());
	}

	public ICCHyperlinks getHyperlinks() {
		return new ICCHyperlinks(Dispatch.get(this, "Hyperlinks").toDispatch());
	}

	public String getOID() {
		return Dispatch.get(this, "OID").toString();
	}

	public String getVOBFamilyUUID() {
		return Dispatch.get(this, "VOBFamilyUUID").toString();
	}

	public String getName() {
		return Dispatch.get(this, "Name").toString();
	}

	public void apply(ICCVersion pVersion, String comment, boolean replace, boolean lastParam) {
		Dispatch.call(this, "Apply", pVersion, comment, new Variant(replace), new Variant(lastParam));
	}

	public void apply(ICCVersion pVersion, String comment, boolean replace) {
		Dispatch.call(this, "Apply", pVersion, comment, new Variant(replace));
	}

	public void apply(ICCVersion pVersion, String comment) {
		Dispatch.call(this, "Apply", pVersion, comment);
	}

	public void apply(ICCVersion pVersion) {
		Dispatch.call(this, "Apply", pVersion);
	}

	public int getConstraint() {
		return Dispatch.get(this, "Constraint").toInt();
	}

	public void createLock(String comment, boolean obsolete, Variant lastParam) {
		Dispatch.call(this, "CreateLock", comment, new Variant(obsolete), lastParam);
	}

	public void createLock(String comment, boolean obsolete) {
		Dispatch.call(this, "CreateLock", comment, new Variant(obsolete));
	}

	public void createLock(String comment) {
		Dispatch.call(this, "CreateLock", comment);
	}

	public void createLock() {
		Dispatch.call(this, "CreateLock");
	}

	public String getGroup() {
		return Dispatch.get(this, "Group").toString();
	}

	public boolean getHasSharedMastership() {
		return Dispatch.get(this, "HasSharedMastership").toBoolean();
	}

	public ICCLock getLock() {
		return new ICCLock(Dispatch.get(this, "Lock").toDispatch());
	}

	public String getMaster() {
		return Dispatch.get(this, "Master").toString();
	}

	public String getOwner() {
		return Dispatch.get(this, "Owner").toString();
	}

	public void removeType(boolean removeAllInstances, String lastParam) {
		Dispatch.call(this, "RemoveType", new Variant(removeAllInstances), lastParam);
	}

	public void removeType(boolean removeAllInstances) {
		Dispatch.call(this, "RemoveType", new Variant(removeAllInstances));
	}

	public void removeType() {
		Dispatch.call(this, "RemoveType");
	}

	public int getScope() {
		return Dispatch.get(this, "Scope").toInt();
	}

	public void setConstraint(int newConstraint, String lastParam) {
		Dispatch.call(this, "SetConstraint", new Variant(newConstraint), lastParam);
	}

	public void setConstraint(int newConstraint) {
		Dispatch.call(this, "SetConstraint", new Variant(newConstraint));
	}

	public void setGroup(String newGroup, String lastParam) {
		Dispatch.call(this, "SetGroup", newGroup, lastParam);
	}

	public void setGroup(String newGroup) {
		Dispatch.call(this, "SetGroup", newGroup);
	}

	public void setMaster(String replica, String lastParam) {
		Dispatch.call(this, "SetMaster", replica, lastParam);
	}

	public void setMaster(String replica) {
		Dispatch.call(this, "SetMaster", replica);
	}

	public void setName(String newName, String lastParam) {
		Dispatch.call(this, "SetName", newName, lastParam);
	}

	public void setName(String newName) {
		Dispatch.call(this, "SetName", newName);
	}

	public void setOwner(String newOwner, String lastParam) {
		Dispatch.call(this, "SetOwner", newOwner, lastParam);
	}

	public void setOwner(String newOwner) {
		Dispatch.call(this, "SetOwner", newOwner);
	}

	public void setScope(boolean global, boolean acquire, String lastParam) {
		Dispatch.call(this, "SetScope", new Variant(global), new Variant(acquire), lastParam);
	}

	public void setScope(boolean global, boolean acquire) {
		Dispatch.call(this, "SetScope", new Variant(global), new Variant(acquire));
	}

	public void setScope(boolean global) {
		Dispatch.call(this, "SetScope", new Variant(global));
	}

	public void shareMastership(String lastParam) {
		Dispatch.call(this, "ShareMastership", lastParam);
	}

	public void shareMastership() {
		Dispatch.call(this, "ShareMastership");
	}

	public ICCVOB getVOB() {
		return new ICCVOB(Dispatch.get(this, "VOB").toDispatch());
	}

}
