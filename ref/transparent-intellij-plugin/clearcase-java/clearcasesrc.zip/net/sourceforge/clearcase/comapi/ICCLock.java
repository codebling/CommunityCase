/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

public class ICCLock extends Dispatch {

	public static final String componentName = "ClearCase.ICCLock";

	public ICCLock() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public ICCLock(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public ICCLock(String compName) {
		super(compName);
	}

	public ICCHistoryRecord getCreationRecord() {
		return new ICCHistoryRecord(Dispatch.get(this, "CreationRecord").toDispatch());
	}

	public Variant getExemptUsersStringArray() {
		return Dispatch.get(this, "ExemptUsersStringArray");
	}

	public boolean getIsObsolete() {
		return Dispatch.get(this, "IsObsolete").toBoolean();
	}

	public ICCVOBObject getLockedObject() {
		return new ICCVOBObject(Dispatch.get(this, "LockedObject").toDispatch());
	}

	public int getNumberOfExemptUsers() {
		return Dispatch.get(this, "NumberOfExemptUsers").toInt();
	}

	public void remove(String lastParam) {
		Dispatch.call(this, "Remove", lastParam);
	}

	public void remove() {
		Dispatch.call(this, "Remove");
	}

	public void setExemptUsersStringArray(Variant exemptUsersStringArray, String lastParam) {
		Dispatch.call(this, "SetExemptUsersStringArray", exemptUsersStringArray, lastParam);
	}

	public void setExemptUsersStringArray(Variant exemptUsersStringArray) {
		Dispatch.call(this, "SetExemptUsersStringArray", exemptUsersStringArray);
	}

	public void setExemptUsersStringArray() {
		Dispatch.call(this, "SetExemptUsersStringArray");
	}

	public void setObsolete(boolean isObsolete, String lastParam) {
		Dispatch.call(this, "SetObsolete", new Variant(isObsolete), lastParam);
	}

	public void setObsolete(boolean isObsolete) {
		Dispatch.call(this, "SetObsolete", new Variant(isObsolete));
	}

	public ICCVOB getVOB() {
		return new ICCVOB(Dispatch.get(this, "VOB").toDispatch());
	}

}
