/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCStreams extends ICCStreams {

	public static final String componentName = "ClearCase.CCStreams";

	public CCStreams() {
		super(componentName);
	}

	public CCStreams(Dispatch d) {
		super(d);
	}
}
