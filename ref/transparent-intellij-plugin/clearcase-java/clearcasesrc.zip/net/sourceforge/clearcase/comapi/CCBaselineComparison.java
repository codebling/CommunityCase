/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCBaselineComparison extends ICCBaselineComparison {

	public static final String componentName = "ClearCase.CCBaselineComparison";

	public CCBaselineComparison() {
		super(componentName);
	}

	public CCBaselineComparison(Dispatch d) {
		super(d);
	}
}
