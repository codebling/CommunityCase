/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCLocks extends ICCLocks {

	public static final String componentName = "ClearCase.CCLocks";

	public CCLocks() {
		super(componentName);
	}

	public CCLocks(Dispatch d) {
		super(d);
	}
}
