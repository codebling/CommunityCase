/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCTriggerTypeBuilder extends ICCTriggerTypeBuilder {

	public static final String componentName = "ClearCase.CCTriggerTypeBuilder";

	public CCTriggerTypeBuilder() {
		super(componentName);
	}

	public CCTriggerTypeBuilder(Dispatch d) {
		super(d);
	}
}
