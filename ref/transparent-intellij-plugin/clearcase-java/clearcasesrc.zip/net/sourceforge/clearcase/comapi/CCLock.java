/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCLock extends ICCLock {

	public static final String componentName = "ClearCase.CCLock";

	public CCLock() {
		super(componentName);
	}

	public CCLock(Dispatch d) {
		super(d);
	}
}
