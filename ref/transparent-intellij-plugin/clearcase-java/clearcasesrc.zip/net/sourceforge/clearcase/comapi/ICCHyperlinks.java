/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

public class ICCHyperlinks extends Dispatch {

	public static final String componentName = "ClearCase.ICCHyperlinks";

	public ICCHyperlinks() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public ICCHyperlinks(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public ICCHyperlinks(String compName) {
		super(compName);
	}

	public ICCHyperlink getItem(int lastParam) {
		return new ICCHyperlink(Dispatch.call(this, "Item", new Variant(lastParam)).toDispatch());
	}

	public void add(ICCHyperlink lastParam) {
		Dispatch.call(this, "Add", lastParam);
	}

	public int getCount() {
		return Dispatch.get(this, "Count").toInt();
	}

	public void remove(int lastParam) {
		Dispatch.call(this, "Remove", new Variant(lastParam));
	}

	public Object get_NewEnum() {
		return Dispatch.get(this, "_NewEnum");
	}

}
