/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;


public interface CCKeepState {

	public static final int ccKeep = 0;
	public static final int ccRemove = 1;
}
