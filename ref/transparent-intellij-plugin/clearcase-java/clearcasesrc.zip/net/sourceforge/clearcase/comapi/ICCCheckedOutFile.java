/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

public class ICCCheckedOutFile extends Dispatch {

	public static final String componentName = "ClearCase.ICCCheckedOutFile";

	public ICCCheckedOutFile() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public ICCCheckedOutFile(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public ICCCheckedOutFile(String compName) {
		super(compName);
	}

	public ICCAttribute getAttribute(String lastParam) {
		return new ICCAttribute(Dispatch.call(this, "Attribute", lastParam).toDispatch());
	}

	public ICCAttributes getAttributes() {
		return new ICCAttributes(Dispatch.get(this, "Attributes").toDispatch());
	}

	public String getComment() {
		return Dispatch.get(this, "Comment").toString();
	}

	public void setComment(String lastParam) {
		Dispatch.put(this, "Comment", lastParam);
	}

	public ICCHistoryRecord getCreationRecord() {
		return new ICCHistoryRecord(Dispatch.get(this, "CreationRecord").toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor, boolean excludeCheckOutEvents, boolean recurse, boolean lastParam) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor), new Variant(excludeCheckOutEvents), new Variant(recurse), new Variant(lastParam)).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor, boolean excludeCheckOutEvents, boolean recurse) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor), new Variant(excludeCheckOutEvents), new Variant(recurse)).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor, boolean excludeCheckOutEvents) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor), new Variant(excludeCheckOutEvents)).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor)).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since)).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType).toDispatch());
	}

	public ICCHyperlinks getHyperlinks(String lastParam) {
		return new ICCHyperlinks(Dispatch.call(this, "Hyperlinks", lastParam).toDispatch());
	}

	public ICCHyperlinks getHyperlinks() {
		return new ICCHyperlinks(Dispatch.get(this, "Hyperlinks").toDispatch());
	}

	public String getOID() {
		return Dispatch.get(this, "OID").toString();
	}

	public String getVOBFamilyUUID() {
		return Dispatch.get(this, "VOBFamilyUUID").toString();
	}

	public String getPath() {
		return Dispatch.get(this, "Path").toString();
	}

	public String getExtendedPath() {
		return Dispatch.get(this, "ExtendedPath").toString();
	}

	public String getExtendedPathInView(ICCView lastParam) {
		return Dispatch.call(this, "ExtendedPathInView", lastParam).toString();
	}

	public boolean getIsDirectory() {
		return Dispatch.get(this, "IsDirectory").toBoolean();
	}

	public String getPathInView(ICCView lastParam) {
		return Dispatch.call(this, "PathInView", lastParam).toString();
	}

	public ICCView getView() {
		return new ICCView(Dispatch.get(this, "View").toDispatch());
	}

	public ICCVOB getVOB() {
		return new ICCVOB(Dispatch.get(this, "VOB").toDispatch());
	}

	public ICCBranch getBranch() {
		return new ICCBranch(Dispatch.get(this, "Branch").toDispatch());
	}

	public ICCCheckedOutFile checkOut(int reservedState, String comment, boolean useHijacked, int version, boolean mustBeLatest, boolean lastParam) {
		return new ICCCheckedOutFile(Dispatch.call(this, "CheckOut", new Variant(reservedState), comment, new Variant(useHijacked), new Variant(version), new Variant(mustBeLatest), new Variant(lastParam)).toDispatch());
	}

	public ICCCheckedOutFile checkOut(int reservedState, String comment, boolean useHijacked, int version, boolean mustBeLatest) {
		return new ICCCheckedOutFile(Dispatch.call(this, "CheckOut", new Variant(reservedState), comment, new Variant(useHijacked), new Variant(version), new Variant(mustBeLatest)).toDispatch());
	}

	public ICCCheckedOutFile checkOut(int reservedState, String comment, boolean useHijacked, int version) {
		return new ICCCheckedOutFile(Dispatch.call(this, "CheckOut", new Variant(reservedState), comment, new Variant(useHijacked), new Variant(version)).toDispatch());
	}

	public ICCCheckedOutFile checkOut(int reservedState, String comment, boolean useHijacked) {
		return new ICCCheckedOutFile(Dispatch.call(this, "CheckOut", new Variant(reservedState), comment, new Variant(useHijacked)).toDispatch());
	}

	public ICCCheckedOutFile checkOut(int reservedState, String comment) {
		return new ICCCheckedOutFile(Dispatch.call(this, "CheckOut", new Variant(reservedState), comment).toDispatch());
	}

	public ICCCheckedOutFile checkOut(int reservedState) {
		return new ICCCheckedOutFile(Dispatch.call(this, "CheckOut", new Variant(reservedState)).toDispatch());
	}

	public ICCElement getElement() {
		return new ICCElement(Dispatch.get(this, "Element").toDispatch());
	}

	public String getIdentifier() {
		return Dispatch.get(this, "Identifier").toString();
	}

	public boolean getIsCheckedOut() {
		return Dispatch.get(this, "IsCheckedOut").toBoolean();
	}

	public boolean getIsDifferent() {
		return Dispatch.get(this, "IsDifferent").toBoolean();
	}

	public boolean getIsHijacked() {
		return Dispatch.get(this, "IsHijacked").toBoolean();
	}

	public boolean getIsLatest() {
		return Dispatch.get(this, "IsLatest").toBoolean();
	}

	public ICCLabel getLabel(String lastParam) {
		return new ICCLabel(Dispatch.call(this, "Label", lastParam).toDispatch());
	}

	public ICCLabels getLabels() {
		return new ICCLabels(Dispatch.get(this, "Labels").toDispatch());
	}

	public ICCVersion getParent() {
		return new ICCVersion(Dispatch.get(this, "Parent").toDispatch());
	}

	public ICCVersion getPredecessor() {
		return new ICCVersion(Dispatch.get(this, "Predecessor").toDispatch());
	}

	public void removeVersion(String comment, boolean dataOnly, boolean evenIfBranches, boolean evenIfLabels, boolean evenIfAttributes, boolean lastParam) {
		Dispatch.call(this, "RemoveVersion", comment, new Variant(dataOnly), new Variant(evenIfBranches), new Variant(evenIfLabels), new Variant(evenIfAttributes), new Variant(lastParam));
	}

	public void removeVersion(String comment, boolean dataOnly, boolean evenIfBranches, boolean evenIfLabels, boolean evenIfAttributes) {
		Dispatch.call(this, "RemoveVersion", comment, new Variant(dataOnly), new Variant(evenIfBranches), new Variant(evenIfLabels), new Variant(evenIfAttributes));
	}

	public void removeVersion(String comment, boolean dataOnly, boolean evenIfBranches, boolean evenIfLabels) {
		Dispatch.call(this, "RemoveVersion", comment, new Variant(dataOnly), new Variant(evenIfBranches), new Variant(evenIfLabels));
	}

	public void removeVersion(String comment, boolean dataOnly, boolean evenIfBranches) {
		Dispatch.call(this, "RemoveVersion", comment, new Variant(dataOnly), new Variant(evenIfBranches));
	}

	public void removeVersion(String comment, boolean dataOnly) {
		Dispatch.call(this, "RemoveVersion", comment, new Variant(dataOnly));
	}

	public void removeVersion(String comment) {
		Dispatch.call(this, "RemoveVersion", comment);
	}

	public void removeVersion() {
		Dispatch.call(this, "RemoveVersion");
	}

	public ICCBranches getSubBranches() {
		return new ICCBranches(Dispatch.get(this, "SubBranches").toDispatch());
	}

	public int getVersionNumber() {
		return Dispatch.get(this, "VersionNumber").toInt();
	}

	public ICCView getByView() {
		return new ICCView(Dispatch.get(this, "ByView").toDispatch());
	}

	public ICCVersion checkIn(String comment, boolean evenIfIdentical, String fromPath, int lastParam) {
		return new ICCVersion(Dispatch.call(this, "CheckIn", comment, new Variant(evenIfIdentical), fromPath, new Variant(lastParam)).toDispatch());
	}

	public ICCVersion checkIn(String comment, boolean evenIfIdentical, String fromPath) {
		return new ICCVersion(Dispatch.call(this, "CheckIn", comment, new Variant(evenIfIdentical), fromPath).toDispatch());
	}

	public ICCVersion checkIn(String comment, boolean evenIfIdentical) {
		return new ICCVersion(Dispatch.call(this, "CheckIn", comment, new Variant(evenIfIdentical)).toDispatch());
	}

	public ICCVersion checkIn(String comment) {
		return new ICCVersion(Dispatch.call(this, "CheckIn", comment).toDispatch());
	}

	public ICCVersion checkIn() {
		return new ICCVersion(Dispatch.call(this, "CheckIn").toDispatch());
	}

	public boolean getIsReserved() {
		return Dispatch.get(this, "IsReserved").toBoolean();
	}

	public void reserve(String lastParam) {
		Dispatch.call(this, "Reserve", lastParam);
	}

	public void reserve() {
		Dispatch.call(this, "Reserve");
	}

	public ICCVersion unCheckOut(int lastParam) {
		return new ICCVersion(Dispatch.call(this, "UnCheckOut", new Variant(lastParam)).toDispatch());
	}

	public void unReserve(String lastParam) {
		Dispatch.call(this, "UnReserve", lastParam);
	}

	public void unReserve() {
		Dispatch.call(this, "UnReserve");
	}

}
