/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCVOBObject extends ICCVOBObject {

	public static final String componentName = "ClearCase.CCVOBObject";

	public CCVOBObject() {
		super(componentName);
	}

	public CCVOBObject(Dispatch d) {
		super(d);
	}
}
