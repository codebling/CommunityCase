/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCViews extends ICCViews {

	public static final String componentName = "ClearCase.CCViews";

	public CCViews() {
		super(componentName);
	}

	public CCViews(Dispatch d) {
		super(d);
	}
}
