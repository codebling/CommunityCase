/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

public class ICCProjectVOB extends Dispatch {

	public static final String componentName = "ClearCase.ICCProjectVOB";

	public ICCProjectVOB() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public ICCProjectVOB(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public ICCProjectVOB(String compName) {
		super(compName);
	}

	public ICCAttribute getAttribute(String lastParam) {
		return new ICCAttribute(Dispatch.call(this, "Attribute", lastParam).toDispatch());
	}

	public ICCAttributes getAttributes() {
		return new ICCAttributes(Dispatch.get(this, "Attributes").toDispatch());
	}

	public String getComment() {
		return Dispatch.get(this, "Comment").toString();
	}

	public void setComment(String lastParam) {
		Dispatch.put(this, "Comment", lastParam);
	}

	public ICCHistoryRecord getCreationRecord() {
		return new ICCHistoryRecord(Dispatch.get(this, "CreationRecord").toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor, boolean excludeCheckOutEvents, boolean recurse, boolean lastParam) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor), new Variant(excludeCheckOutEvents), new Variant(recurse), new Variant(lastParam)).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor, boolean excludeCheckOutEvents, boolean recurse) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor), new Variant(excludeCheckOutEvents), new Variant(recurse)).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor, boolean excludeCheckOutEvents) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor), new Variant(excludeCheckOutEvents)).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor)).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since)).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType).toDispatch());
	}

	public ICCHyperlinks getHyperlinks(String lastParam) {
		return new ICCHyperlinks(Dispatch.call(this, "Hyperlinks", lastParam).toDispatch());
	}

	public ICCHyperlinks getHyperlinks() {
		return new ICCHyperlinks(Dispatch.get(this, "Hyperlinks").toDispatch());
	}

	public String getOID() {
		return Dispatch.get(this, "OID").toString();
	}

	public String getVOBFamilyUUID() {
		return Dispatch.get(this, "VOBFamilyUUID").toString();
	}

	public String getTagName() {
		return Dispatch.get(this, "TagName").toString();
	}

	public ICCActivity getActivity(String lastParam) {
		return new ICCActivity(Dispatch.call(this, "Activity", lastParam).toDispatch());
	}

	public Variant getAdditionalGroupsStringArray() {
		return Dispatch.get(this, "AdditionalGroupsStringArray");
	}

	public ICCAttributeType getAttributeType(String name, boolean lastParam) {
		return new ICCAttributeType(Dispatch.call(this, "AttributeType", name, new Variant(lastParam)).toDispatch());
	}

	public ICCAttributeType getAttributeType(String name) {
		return new ICCAttributeType(Dispatch.call(this, "AttributeType", name).toDispatch());
	}

	public ICCAttributeTypes getAttributeTypes(boolean local, boolean lastParam) {
		return new ICCAttributeTypes(Dispatch.call(this, "AttributeTypes", new Variant(local), new Variant(lastParam)).toDispatch());
	}

	public ICCAttributeTypes getAttributeTypes(boolean local) {
		return new ICCAttributeTypes(Dispatch.call(this, "AttributeTypes", new Variant(local)).toDispatch());
	}

	public ICCAttributeTypes getAttributeTypes() {
		return new ICCAttributeTypes(Dispatch.get(this, "AttributeTypes").toDispatch());
	}

	public ICCBranchType getBranchType(String name, boolean lastParam) {
		return new ICCBranchType(Dispatch.call(this, "BranchType", name, new Variant(lastParam)).toDispatch());
	}

	public ICCBranchType getBranchType(String name) {
		return new ICCBranchType(Dispatch.call(this, "BranchType", name).toDispatch());
	}

	public ICCBranchTypes getBranchTypes(boolean local, boolean lastParam) {
		return new ICCBranchTypes(Dispatch.call(this, "BranchTypes", new Variant(local), new Variant(lastParam)).toDispatch());
	}

	public ICCBranchTypes getBranchTypes(boolean local) {
		return new ICCBranchTypes(Dispatch.call(this, "BranchTypes", new Variant(local)).toDispatch());
	}

	public ICCBranchTypes getBranchTypes() {
		return new ICCBranchTypes(Dispatch.get(this, "BranchTypes").toDispatch());
	}

	public ICCAttributeType createAttributeType(String name, int valueType, String comment, boolean shared, int constraint, boolean global, boolean lastParam) {
		return new ICCAttributeType(Dispatch.call(this, "CreateAttributeType", name, new Variant(valueType), comment, new Variant(shared), new Variant(constraint), new Variant(global), new Variant(lastParam)).toDispatch());
	}

	public ICCAttributeType createAttributeType(String name, int valueType, String comment, boolean shared, int constraint, boolean global) {
		return new ICCAttributeType(Dispatch.call(this, "CreateAttributeType", name, new Variant(valueType), comment, new Variant(shared), new Variant(constraint), new Variant(global)).toDispatch());
	}

	public ICCAttributeType createAttributeType(String name, int valueType, String comment, boolean shared, int constraint) {
		return new ICCAttributeType(Dispatch.call(this, "CreateAttributeType", name, new Variant(valueType), comment, new Variant(shared), new Variant(constraint)).toDispatch());
	}

	public ICCAttributeType createAttributeType(String name, int valueType, String comment, boolean shared) {
		return new ICCAttributeType(Dispatch.call(this, "CreateAttributeType", name, new Variant(valueType), comment, new Variant(shared)).toDispatch());
	}

	public ICCAttributeType createAttributeType(String name, int valueType, String comment) {
		return new ICCAttributeType(Dispatch.call(this, "CreateAttributeType", name, new Variant(valueType), comment).toDispatch());
	}

	public ICCAttributeType createAttributeType(String name, int valueType) {
		return new ICCAttributeType(Dispatch.call(this, "CreateAttributeType", name, new Variant(valueType)).toDispatch());
	}

	public ICCAttributeType createAttributeType(String name) {
		return new ICCAttributeType(Dispatch.call(this, "CreateAttributeType", name).toDispatch());
	}

	public ICCBranchType createBranchType(String name, String comment, int constraint, boolean global, boolean lastParam) {
		return new ICCBranchType(Dispatch.call(this, "CreateBranchType", name, comment, new Variant(constraint), new Variant(global), new Variant(lastParam)).toDispatch());
	}

	public ICCBranchType createBranchType(String name, String comment, int constraint, boolean global) {
		return new ICCBranchType(Dispatch.call(this, "CreateBranchType", name, comment, new Variant(constraint), new Variant(global)).toDispatch());
	}

	public ICCBranchType createBranchType(String name, String comment, int constraint) {
		return new ICCBranchType(Dispatch.call(this, "CreateBranchType", name, comment, new Variant(constraint)).toDispatch());
	}

	public ICCBranchType createBranchType(String name, String comment) {
		return new ICCBranchType(Dispatch.call(this, "CreateBranchType", name, comment).toDispatch());
	}

	public ICCBranchType createBranchType(String name) {
		return new ICCBranchType(Dispatch.call(this, "CreateBranchType", name).toDispatch());
	}

	public ICCHyperlinkType createHyperlinkType(String name, String comment, boolean shared, boolean global, boolean lastParam) {
		return new ICCHyperlinkType(Dispatch.call(this, "CreateHyperlinkType", name, comment, new Variant(shared), new Variant(global), new Variant(lastParam)).toDispatch());
	}

	public ICCHyperlinkType createHyperlinkType(String name, String comment, boolean shared, boolean global) {
		return new ICCHyperlinkType(Dispatch.call(this, "CreateHyperlinkType", name, comment, new Variant(shared), new Variant(global)).toDispatch());
	}

	public ICCHyperlinkType createHyperlinkType(String name, String comment, boolean shared) {
		return new ICCHyperlinkType(Dispatch.call(this, "CreateHyperlinkType", name, comment, new Variant(shared)).toDispatch());
	}

	public ICCHyperlinkType createHyperlinkType(String name, String comment) {
		return new ICCHyperlinkType(Dispatch.call(this, "CreateHyperlinkType", name, comment).toDispatch());
	}

	public ICCHyperlinkType createHyperlinkType(String name) {
		return new ICCHyperlinkType(Dispatch.call(this, "CreateHyperlinkType", name).toDispatch());
	}

	public ICCLabelType createLabelType(String name, String comment, boolean shared, int constraint, boolean global, boolean lastParam) {
		return new ICCLabelType(Dispatch.call(this, "CreateLabelType", name, comment, new Variant(shared), new Variant(constraint), new Variant(global), new Variant(lastParam)).toDispatch());
	}

	public ICCLabelType createLabelType(String name, String comment, boolean shared, int constraint, boolean global) {
		return new ICCLabelType(Dispatch.call(this, "CreateLabelType", name, comment, new Variant(shared), new Variant(constraint), new Variant(global)).toDispatch());
	}

	public ICCLabelType createLabelType(String name, String comment, boolean shared, int constraint) {
		return new ICCLabelType(Dispatch.call(this, "CreateLabelType", name, comment, new Variant(shared), new Variant(constraint)).toDispatch());
	}

	public ICCLabelType createLabelType(String name, String comment, boolean shared) {
		return new ICCLabelType(Dispatch.call(this, "CreateLabelType", name, comment, new Variant(shared)).toDispatch());
	}

	public ICCLabelType createLabelType(String name, String comment) {
		return new ICCLabelType(Dispatch.call(this, "CreateLabelType", name, comment).toDispatch());
	}

	public ICCLabelType createLabelType(String name) {
		return new ICCLabelType(Dispatch.call(this, "CreateLabelType", name).toDispatch());
	}

	public void createLock(String comment, boolean obsolete, Variant lastParam) {
		Dispatch.call(this, "CreateLock", comment, new Variant(obsolete), lastParam);
	}

	public void createLock(String comment, boolean obsolete) {
		Dispatch.call(this, "CreateLock", comment, new Variant(obsolete));
	}

	public void createLock(String comment) {
		Dispatch.call(this, "CreateLock", comment);
	}

	public void createLock() {
		Dispatch.call(this, "CreateLock");
	}

	public ICCTriggerTypeBuilder createTriggerTypeBuilder() {
		return new ICCTriggerTypeBuilder(Dispatch.call(this, "CreateTriggerTypeBuilder").toDispatch());
	}

	public String getGroup() {
		return Dispatch.get(this, "Group").toString();
	}

	public boolean getHasMSDOSTextMode() {
		return Dispatch.get(this, "HasMSDOSTextMode").toBoolean();
	}

	public String getHost() {
		return Dispatch.get(this, "Host").toString();
	}

	public ICCHyperlink getHyperlink(String lastParam) {
		return new ICCHyperlink(Dispatch.call(this, "Hyperlink", lastParam).toDispatch());
	}

	public ICCHyperlinkType getHyperlinkType(String name, boolean lastParam) {
		return new ICCHyperlinkType(Dispatch.call(this, "HyperlinkType", name, new Variant(lastParam)).toDispatch());
	}

	public ICCHyperlinkType getHyperlinkType(String name) {
		return new ICCHyperlinkType(Dispatch.call(this, "HyperlinkType", name).toDispatch());
	}

	public ICCHyperlinkTypes getHyperlinkTypes(boolean local, boolean lastParam) {
		return new ICCHyperlinkTypes(Dispatch.call(this, "HyperlinkTypes", new Variant(local), new Variant(lastParam)).toDispatch());
	}

	public ICCHyperlinkTypes getHyperlinkTypes(boolean local) {
		return new ICCHyperlinkTypes(Dispatch.call(this, "HyperlinkTypes", new Variant(local)).toDispatch());
	}

	public ICCHyperlinkTypes getHyperlinkTypes() {
		return new ICCHyperlinkTypes(Dispatch.get(this, "HyperlinkTypes").toDispatch());
	}

	public boolean getIsMounted() {
		return Dispatch.get(this, "IsMounted").toBoolean();
	}

	public void setIsMounted(boolean lastParam) {
		Dispatch.put(this, "IsMounted", new Variant(lastParam));
	}

	public void setIsPersistent(boolean lastParam) {
		Dispatch.put(this, "IsPersistent", new Variant(lastParam));
	}

	public boolean getIsReplicated() {
		return Dispatch.get(this, "IsReplicated").toBoolean();
	}

	public ICCLabelType getLabelType(String name, boolean lastParam) {
		return new ICCLabelType(Dispatch.call(this, "LabelType", name, new Variant(lastParam)).toDispatch());
	}

	public ICCLabelType getLabelType(String name) {
		return new ICCLabelType(Dispatch.call(this, "LabelType", name).toDispatch());
	}

	public ICCLabelTypes getLabelTypes(boolean local, boolean lastParam) {
		return new ICCLabelTypes(Dispatch.call(this, "LabelTypes", new Variant(local), new Variant(lastParam)).toDispatch());
	}

	public ICCLabelTypes getLabelTypes(boolean local) {
		return new ICCLabelTypes(Dispatch.call(this, "LabelTypes", new Variant(local)).toDispatch());
	}

	public ICCLabelTypes getLabelTypes() {
		return new ICCLabelTypes(Dispatch.get(this, "LabelTypes").toDispatch());
	}

	public ICCLock getLock() {
		return new ICCLock(Dispatch.get(this, "Lock").toDispatch());
	}

	public ICCLocks getLocks(boolean lastParam) {
		return new ICCLocks(Dispatch.call(this, "Locks", new Variant(lastParam)).toDispatch());
	}

	public ICCLocks getLocks() {
		return new ICCLocks(Dispatch.get(this, "Locks").toDispatch());
	}

	public String getMaster() {
		return Dispatch.get(this, "Master").toString();
	}

	public int getNumberOfAdditionalGroups() {
		return Dispatch.get(this, "NumberOfAdditionalGroups").toInt();
	}

	public int getNumberOfReplicas() {
		return Dispatch.get(this, "NumberOfReplicas").toInt();
	}

	public String getOwner() {
		return Dispatch.get(this, "Owner").toString();
	}

	public void protect(String newOwner, String newGroup, Variant groupsToAddStringArray, Variant lastParam) {
		Dispatch.call(this, "Protect", newOwner, newGroup, groupsToAddStringArray, lastParam);
	}

	public void protect(String newOwner, String newGroup, Variant groupsToAddStringArray) {
		Dispatch.call(this, "Protect", newOwner, newGroup, groupsToAddStringArray);
	}

	public void protect(String newOwner, String newGroup) {
		Dispatch.call(this, "Protect", newOwner, newGroup);
	}

	public void protect(String newOwner) {
		Dispatch.call(this, "Protect", newOwner);
	}

	public void protect() {
		Dispatch.call(this, "Protect");
	}

	public Variant getReplicasStringArray() {
		return Dispatch.get(this, "ReplicasStringArray");
	}

	public void setMaster(String replica, String lastParam) {
		Dispatch.call(this, "SetMaster", replica, lastParam);
	}

	public void setMaster(String replica) {
		Dispatch.call(this, "SetMaster", replica);
	}

	public String getThisReplica() {
		return Dispatch.get(this, "ThisReplica").toString();
	}

	public ICCTriggerType getTriggerType(String lastParam) {
		return new ICCTriggerType(Dispatch.call(this, "TriggerType", lastParam).toDispatch());
	}

	public ICCTriggerTypes getTriggerTypes(boolean lastParam) {
		return new ICCTriggerTypes(Dispatch.call(this, "TriggerTypes", new Variant(lastParam)).toDispatch());
	}

	public ICCTriggerTypes getTriggerTypes() {
		return new ICCTriggerTypes(Dispatch.get(this, "TriggerTypes").toDispatch());
	}

	public ICCBaseline getBaseline(String lastParam) {
		return new ICCBaseline(Dispatch.call(this, "Baseline", lastParam).toDispatch());
	}

	public ICCComponent getComponent(String lastParam) {
		return new ICCComponent(Dispatch.call(this, "Component", lastParam).toDispatch());
	}

	public ICCComponents getComponents() {
		return new ICCComponents(Dispatch.get(this, "Components").toDispatch());
	}

	public String getDefaultPromotionLevel() {
		return Dispatch.get(this, "DefaultPromotionLevel").toString();
	}

	public ICCFolder getFolder(String lastParam) {
		return new ICCFolder(Dispatch.call(this, "Folder", lastParam).toDispatch());
	}

	public int getNumberOfPromotionLevels() {
		return Dispatch.get(this, "NumberOfPromotionLevels").toInt();
	}

	public ICCProject getProject(String lastParam) {
		return new ICCProject(Dispatch.call(this, "Project", lastParam).toDispatch());
	}

	public ICCProjects getProjects() {
		return new ICCProjects(Dispatch.get(this, "Projects").toDispatch());
	}

	public Variant getPromotionLevelsStringArray() {
		return Dispatch.get(this, "PromotionLevelsStringArray");
	}

	public ICCFolder getRootFolder() {
		return new ICCFolder(Dispatch.get(this, "RootFolder").toDispatch());
	}

	public ICCStream getStream(String lastParam) {
		return new ICCStream(Dispatch.call(this, "Stream", lastParam).toDispatch());
	}

}
