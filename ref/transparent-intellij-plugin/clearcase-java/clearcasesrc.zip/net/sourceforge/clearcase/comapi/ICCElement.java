/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

public class ICCElement extends Dispatch {

	public static final String componentName = "ClearCase.ICCElement";

	public ICCElement() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public ICCElement(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public ICCElement(String compName) {
		super(compName);
	}

	public ICCAttribute getAttribute(String lastParam) {
		return new ICCAttribute(Dispatch.call(this, "Attribute", lastParam).toDispatch());
	}

	public ICCAttributes getAttributes() {
		return new ICCAttributes(Dispatch.get(this, "Attributes").toDispatch());
	}

	public String getComment() {
		return Dispatch.get(this, "Comment").toString();
	}

	public void setComment(String lastParam) {
		Dispatch.put(this, "Comment", lastParam);
	}

	public ICCHistoryRecord getCreationRecord() {
		return new ICCHistoryRecord(Dispatch.get(this, "CreationRecord").toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor, boolean excludeCheckOutEvents, boolean recurse, boolean lastParam) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor), new Variant(excludeCheckOutEvents), new Variant(recurse), new Variant(lastParam)).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor, boolean excludeCheckOutEvents, boolean recurse) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor), new Variant(excludeCheckOutEvents), new Variant(recurse)).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor, boolean excludeCheckOutEvents) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor), new Variant(excludeCheckOutEvents)).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor)).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since)).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType).toDispatch());
	}

	public ICCHyperlinks getHyperlinks(String lastParam) {
		return new ICCHyperlinks(Dispatch.call(this, "Hyperlinks", lastParam).toDispatch());
	}

	public ICCHyperlinks getHyperlinks() {
		return new ICCHyperlinks(Dispatch.get(this, "Hyperlinks").toDispatch());
	}

	public String getOID() {
		return Dispatch.get(this, "OID").toString();
	}

	public String getVOBFamilyUUID() {
		return Dispatch.get(this, "VOBFamilyUUID").toString();
	}

	public String getPath() {
		return Dispatch.get(this, "Path").toString();
	}

	public String getExtendedPath() {
		return Dispatch.get(this, "ExtendedPath").toString();
	}

	public String getExtendedPathInView(ICCView lastParam) {
		return Dispatch.call(this, "ExtendedPathInView", lastParam).toString();
	}

	public boolean getIsDirectory() {
		return Dispatch.get(this, "IsDirectory").toBoolean();
	}

	public String getPathInView(ICCView lastParam) {
		return Dispatch.call(this, "PathInView", lastParam).toString();
	}

	public ICCView getView() {
		return new ICCView(Dispatch.get(this, "View").toDispatch());
	}

	public ICCVOB getVOB() {
		return new ICCVOB(Dispatch.get(this, "VOB").toDispatch());
	}

	public ICCCheckedOutFile getCheckedOutFile() {
		return new ICCCheckedOutFile(Dispatch.get(this, "CheckedOutFile").toDispatch());
	}

	public void createLock(String comment, boolean obsolete, Variant lastParam) {
		Dispatch.call(this, "CreateLock", comment, new Variant(obsolete), lastParam);
	}

	public void createLock(String comment, boolean obsolete) {
		Dispatch.call(this, "CreateLock", comment, new Variant(obsolete));
	}

	public void createLock(String comment) {
		Dispatch.call(this, "CreateLock", comment);
	}

	public void createLock() {
		Dispatch.call(this, "CreateLock");
	}

	public String getElementType() {
		return Dispatch.get(this, "ElementType").toString();
	}

	public String getGroup() {
		return Dispatch.get(this, "Group").toString();
	}

	public ICCLock getLock() {
		return new ICCLock(Dispatch.get(this, "Lock").toDispatch());
	}

	public String getMaster() {
		return Dispatch.get(this, "Master").toString();
	}

	public void move(ICCElement pNewParent, String lastParam) {
		Dispatch.call(this, "Move", pNewParent, lastParam);
	}

	public void move(ICCElement pNewParent) {
		Dispatch.call(this, "Move", pNewParent);
	}

	public String getOwner() {
		return Dispatch.get(this, "Owner").toString();
	}

	public ICCElement getParent() {
		return new ICCElement(Dispatch.get(this, "Parent").toDispatch());
	}

	public int getPermissions() {
		return Dispatch.get(this, "Permissions").toInt();
	}

	public void removeElement(String lastParam) {
		Dispatch.call(this, "RemoveElement", lastParam);
	}

	public void removeElement() {
		Dispatch.call(this, "RemoveElement");
	}

	public void removeName(String comment, boolean lastParam) {
		Dispatch.call(this, "RemoveName", comment, new Variant(lastParam));
	}

	public void removeName(String comment) {
		Dispatch.call(this, "RemoveName", comment);
	}

	public void removeName() {
		Dispatch.call(this, "RemoveName");
	}

	public void rename(String newName, String lastParam) {
		Dispatch.call(this, "Rename", newName, lastParam);
	}

	public void rename(String newName) {
		Dispatch.call(this, "Rename", newName);
	}

	public void setGroup(String newGroup, String lastParam) {
		Dispatch.call(this, "SetGroup", newGroup, lastParam);
	}

	public void setGroup(String newGroup) {
		Dispatch.call(this, "SetGroup", newGroup);
	}

	public void setMaster(String replica, String lastParam) {
		Dispatch.call(this, "SetMaster", replica, lastParam);
	}

	public void setMaster(String replica) {
		Dispatch.call(this, "SetMaster", replica);
	}

	public void setOwner(String newOwner, String lastParam) {
		Dispatch.call(this, "SetOwner", newOwner, lastParam);
	}

	public void setOwner(String newOwner) {
		Dispatch.call(this, "SetOwner", newOwner);
	}

	public void setPermissions(int newPermissions, String lastParam) {
		Dispatch.call(this, "SetPermissions", new Variant(newPermissions), lastParam);
	}

	public void setPermissions(int newPermissions) {
		Dispatch.call(this, "SetPermissions", new Variant(newPermissions));
	}

	public ICCTrigger getTrigger(String lastParam) {
		return new ICCTrigger(Dispatch.call(this, "Trigger", lastParam).toDispatch());
	}

	public ICCTriggers getTriggers() {
		return new ICCTriggers(Dispatch.get(this, "Triggers").toDispatch());
	}

	public ICCVersion getVersion(String lastParam) {
		return new ICCVersion(Dispatch.call(this, "Version", lastParam).toDispatch());
	}

	public ICCVersion getVersion() {
		return new ICCVersion(Dispatch.get(this, "Version").toDispatch());
	}

}
