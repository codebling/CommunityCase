/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

public class ICCViews extends Dispatch {

	public static final String componentName = "ClearCase.ICCViews";

	public ICCViews() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public ICCViews(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public ICCViews(String compName) {
		super(compName);
	}

	public ICCView getItem(int lastParam) {
		return new ICCView(Dispatch.call(this, "Item", new Variant(lastParam)).toDispatch());
	}

	public void add(ICCView lastParam) {
		Dispatch.call(this, "Add", lastParam);
	}

	public int getCount() {
		return Dispatch.get(this, "Count").toInt();
	}

	public void remove(int lastParam) {
		Dispatch.call(this, "Remove", new Variant(lastParam));
	}

	public String getInitErrors() {
		return Dispatch.get(this, "InitErrors").toString();
	}

	public Object get_NewEnum() {
		return Dispatch.get(this, "_NewEnum");
	}

}
