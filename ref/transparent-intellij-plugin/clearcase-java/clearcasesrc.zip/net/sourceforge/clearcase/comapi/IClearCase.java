/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

public class IClearCase extends Dispatch {

	public static final String componentName = "ClearCase.IClearCase";

	public IClearCase() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public IClearCase(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public IClearCase(String compName) {
		super(compName);
	}

	public ICCActivity getActivity(String lastParam) {
		return new ICCActivity(Dispatch.call(this, "Activity", lastParam).toDispatch());
	}

	public ICCAttributes getAttributesEmpty() {
		return new ICCAttributes(Dispatch.get(this, "AttributesEmpty").toDispatch());
	}

	public ICCAttributeTypes getAttributeTypesEmpty() {
		return new ICCAttributeTypes(Dispatch.get(this, "AttributeTypesEmpty").toDispatch());
	}

	public ICCBranches getBranchesEmpty() {
		return new ICCBranches(Dispatch.get(this, "BranchesEmpty").toDispatch());
	}

	public ICCBranchTypes getBranchTypesEmpty() {
		return new ICCBranchTypes(Dispatch.get(this, "BranchTypesEmpty").toDispatch());
	}

	public ICCCheckedOutFile getCheckedOutFile(String lastParam) {
		return new ICCCheckedOutFile(Dispatch.call(this, "CheckedOutFile", lastParam).toDispatch());
	}

	public ICCCheckedOutFiles getCheckedOutFilesEmpty() {
		return new ICCCheckedOutFiles(Dispatch.get(this, "CheckedOutFilesEmpty").toDispatch());
	}

	public void checkLicense() {
		Dispatch.call(this, "CheckLicense");
	}

	public ICCCheckedOutFileQuery createCheckedOutFileQuery() {
		return new ICCCheckedOutFileQuery(Dispatch.call(this, "CreateCheckedOutFileQuery").toDispatch());
	}

	public ICCCheckedOutFile createElement(String path, String comment, boolean setMaster, Variant lastParam) {
		return new ICCCheckedOutFile(Dispatch.call(this, "CreateElement", path, comment, new Variant(setMaster), lastParam).toDispatch());
	}

	public ICCCheckedOutFile createElement(String path, String comment, boolean setMaster) {
		return new ICCCheckedOutFile(Dispatch.call(this, "CreateElement", path, comment, new Variant(setMaster)).toDispatch());
	}

	public ICCCheckedOutFile createElement(String path, String comment) {
		return new ICCCheckedOutFile(Dispatch.call(this, "CreateElement", path, comment).toDispatch());
	}

	public ICCCheckedOutFile createElement(String path) {
		return new ICCCheckedOutFile(Dispatch.call(this, "CreateElement", path).toDispatch());
	}

	public ICCElement getElement(String lastParam) {
		return new ICCElement(Dispatch.call(this, "Element", lastParam).toDispatch());
	}

	public ICCElements getElementsEmpty() {
		return new ICCElements(Dispatch.get(this, "ElementsEmpty").toDispatch());
	}

	public ICCHistoryRecords getHistoryRecordsEmpty() {
		return new ICCHistoryRecords(Dispatch.get(this, "HistoryRecordsEmpty").toDispatch());
	}

	public ICCHyperlink getHyperlink(String lastParam) {
		return new ICCHyperlink(Dispatch.call(this, "Hyperlink", lastParam).toDispatch());
	}

	public ICCHyperlinks getHyperlinksEmpty() {
		return new ICCHyperlinks(Dispatch.get(this, "HyperlinksEmpty").toDispatch());
	}

	public ICCHyperlinkTypes getHyperlinkTypesEmpty() {
		return new ICCHyperlinkTypes(Dispatch.get(this, "HyperlinkTypesEmpty").toDispatch());
	}

	public void setIsWebGUI(boolean lastParam) {
		Dispatch.put(this, "IsWebGUI", new Variant(lastParam));
	}

	public ICCLabels getLabelsEmpty() {
		return new ICCLabels(Dispatch.get(this, "LabelsEmpty").toDispatch());
	}

	public ICCLabelTypes getLabelTypesEmpty() {
		return new ICCLabelTypes(Dispatch.get(this, "LabelTypesEmpty").toDispatch());
	}

	public ICCLocks getLocksEmpty() {
		return new ICCLocks(Dispatch.get(this, "LocksEmpty").toDispatch());
	}

	public void setAbortPrompts() {
		Dispatch.call(this, "SetAbortPrompts");
	}

	public ICCTriggers getTriggersEmpty() {
		return new ICCTriggers(Dispatch.get(this, "TriggersEmpty").toDispatch());
	}

	public ICCTriggerTypes getTriggerTypesEmpty() {
		return new ICCTriggerTypes(Dispatch.get(this, "TriggerTypesEmpty").toDispatch());
	}

	public ICCVersion getVersion(Variant lastParam) {
		return new ICCVersion(Dispatch.call(this, "Version", lastParam).toDispatch());
	}

	public ICCVersions getVersionsEmpty() {
		return new ICCVersions(Dispatch.get(this, "VersionsEmpty").toDispatch());
	}

	public ICCView getView(String lastParam) {
		return new ICCView(Dispatch.call(this, "View", lastParam).toDispatch());
	}

	public ICCView getView() {
		return new ICCView(Dispatch.get(this, "View").toDispatch());
	}

	public ICCViews getViews(boolean failIfErrors, String lastParam) {
		return new ICCViews(Dispatch.call(this, "Views", new Variant(failIfErrors), lastParam).toDispatch());
	}

	public ICCViews getViews(boolean failIfErrors) {
		return new ICCViews(Dispatch.call(this, "Views", new Variant(failIfErrors)).toDispatch());
	}

	public ICCViews getViews() {
		return new ICCViews(Dispatch.get(this, "Views").toDispatch());
	}

	public ICCViews getViewsEmpty() {
		return new ICCViews(Dispatch.get(this, "ViewsEmpty").toDispatch());
	}

	public ICCVOB getVOB(String lastParam) {
		return new ICCVOB(Dispatch.call(this, "VOB", lastParam).toDispatch());
	}

	public ICCVOBs getVOBs(boolean failIfErrors, String lastParam) {
		return new ICCVOBs(Dispatch.call(this, "VOBs", new Variant(failIfErrors), lastParam).toDispatch());
	}

	public ICCVOBs getVOBs(boolean failIfErrors) {
		return new ICCVOBs(Dispatch.call(this, "VOBs", new Variant(failIfErrors)).toDispatch());
	}

	public ICCVOBs getVOBs() {
		return new ICCVOBs(Dispatch.get(this, "VOBs").toDispatch());
	}

	public ICCVOBs getVOBsEmpty() {
		return new ICCVOBs(Dispatch.get(this, "VOBsEmpty").toDispatch());
	}

	public ICCActivities getActivitiesEmpty() {
		return new ICCActivities(Dispatch.get(this, "ActivitiesEmpty").toDispatch());
	}

	public ICCActivity getActivityOfVersion(ICCVersion lastParam) {
		return new ICCActivity(Dispatch.call(this, "ActivityOfVersion", lastParam).toDispatch());
	}

	public ICCBaseline getBaseline(String lastParam) {
		return new ICCBaseline(Dispatch.call(this, "Baseline", lastParam).toDispatch());
	}

	public ICCBaselines getBaselinesEmpty() {
		return new ICCBaselines(Dispatch.get(this, "BaselinesEmpty").toDispatch());
	}

	public ICCComponent getComponent(String lastParam) {
		return new ICCComponent(Dispatch.call(this, "Component", lastParam).toDispatch());
	}

	public ICCComponents getComponentsEmpty() {
		return new ICCComponents(Dispatch.get(this, "ComponentsEmpty").toDispatch());
	}

	public ICCBaselineComparison createBaselineComparison() {
		return new ICCBaselineComparison(Dispatch.call(this, "CreateBaselineComparison").toDispatch());
	}

	public ICCFolder getFolder(String lastParam) {
		return new ICCFolder(Dispatch.call(this, "Folder", lastParam).toDispatch());
	}

	public ICCFolders getFoldersEmpty() {
		return new ICCFolders(Dispatch.get(this, "FoldersEmpty").toDispatch());
	}

	public boolean getIsClearCaseLT() {
		return Dispatch.get(this, "IsClearCaseLT").toBoolean();
	}

	public boolean getIsClearCaseLTClient() {
		return Dispatch.get(this, "IsClearCaseLTClient").toBoolean();
	}

	public boolean getIsClearCaseLTServer() {
		return Dispatch.get(this, "IsClearCaseLTServer").toBoolean();
	}

	public ICCProject getProject(String lastParam) {
		return new ICCProject(Dispatch.call(this, "Project", lastParam).toDispatch());
	}

	public ICCProjects getProjectsEmpty() {
		return new ICCProjects(Dispatch.get(this, "ProjectsEmpty").toDispatch());
	}

	public ICCProjectVOB getProjectVOB(String lastParam) {
		return new ICCProjectVOB(Dispatch.call(this, "ProjectVOB", lastParam).toDispatch());
	}

	public ICCProjectVOBs getProjectVOBsEmpty() {
		return new ICCProjectVOBs(Dispatch.get(this, "ProjectVOBsEmpty").toDispatch());
	}

	public ICCStream getStream(String lastParam) {
		return new ICCStream(Dispatch.call(this, "Stream", lastParam).toDispatch());
	}

	public ICCStreams getStreamsEmpty() {
		return new ICCStreams(Dispatch.get(this, "StreamsEmpty").toDispatch());
	}

	public String getUniversalSelector(ICCVOBObject lastParam) {
		return Dispatch.call(this, "UniversalSelector", lastParam).toString();
	}

}
