/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCCheckedOutFileQuery extends ICCCheckedOutFileQuery {

	public static final String componentName = "ClearCase.CCCheckedOutFileQuery";

	public CCCheckedOutFileQuery() {
		super(componentName);
	}

	public CCCheckedOutFileQuery(Dispatch d) {
		super(d);
	}
}
