/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

public class ICCTrigger extends Dispatch {

	public static final String componentName = "ClearCase.ICCTrigger";

	public ICCTrigger() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public ICCTrigger(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public ICCTrigger(String compName) {
		super(compName);
	}

	public boolean getIsOnAttachedList() {
		return Dispatch.get(this, "IsOnAttachedList").toBoolean();
	}

	public boolean getIsOnInheritanceList() {
		return Dispatch.get(this, "IsOnInheritanceList").toBoolean();
	}

	public void remove(String comment, boolean recurse, Variant lastParam) {
		Dispatch.call(this, "Remove", comment, new Variant(recurse), lastParam);
	}

	public void remove(String comment, boolean recurse) {
		Dispatch.call(this, "Remove", comment, new Variant(recurse));
	}

	public void remove(String comment) {
		Dispatch.call(this, "Remove", comment);
	}

	public void remove() {
		Dispatch.call(this, "Remove");
	}

	public ICCTriggerType getType() {
		return new ICCTriggerType(Dispatch.get(this, "Type").toDispatch());
	}

	public ICCVOB getVOB() {
		return new ICCVOB(Dispatch.get(this, "VOB").toDispatch());
	}

}
