/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCAttributeTypes extends ICCAttributeTypes {

	public static final String componentName = "ClearCase.CCAttributeTypes";

	public CCAttributeTypes() {
		super(componentName);
	}

	public CCAttributeTypes(Dispatch d) {
		super(d);
	}
}
