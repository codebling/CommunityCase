/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

public class ICCView extends Dispatch {

	public static final String componentName = "ClearCase.ICCView";

	public ICCView() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public ICCView(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public ICCView(String compName) {
		super(compName);
	}

	public String getTagName() {
		return Dispatch.get(this, "TagName").toString();
	}

	public boolean getBuildsNonShareableDOs() {
		return Dispatch.get(this, "BuildsNonShareableDOs").toBoolean();
	}

	public void setBuildsNonShareableDOs(boolean lastParam) {
		Dispatch.put(this, "BuildsNonShareableDOs", new Variant(lastParam));
	}

	public String getConfigSpec() {
		return Dispatch.get(this, "ConfigSpec").toString();
	}

	public void setConfigSpec(String lastParam) {
		Dispatch.put(this, "ConfigSpec", lastParam);
	}

	public String getDisplayableConfigSpec() {
		return Dispatch.get(this, "DisplayableConfigSpec").toString();
	}

	public String getHost() {
		return Dispatch.get(this, "Host").toString();
	}

	public boolean getIsActive() {
		return Dispatch.get(this, "IsActive").toBoolean();
	}

	public void setIsActive(boolean lastParam) {
		Dispatch.put(this, "IsActive", new Variant(lastParam));
	}

	public boolean getIsSnapShot() {
		return Dispatch.get(this, "IsSnapShot").toBoolean();
	}

	public ICCActivity getCurrentActivity() {
		return new ICCActivity(Dispatch.get(this, "CurrentActivity").toDispatch());
	}

	public boolean getIsUCMView() {
		return Dispatch.get(this, "IsUCMView").toBoolean();
	}

	public void setActivity(ICCActivity newActivity, String lastParam) {
		Dispatch.call(this, "SetActivity", newActivity, lastParam);
	}

	public void setActivity(ICCActivity newActivity) {
		Dispatch.call(this, "SetActivity", newActivity);
	}

	public ICCStream getStream() {
		return new ICCStream(Dispatch.get(this, "Stream").toDispatch());
	}

}
