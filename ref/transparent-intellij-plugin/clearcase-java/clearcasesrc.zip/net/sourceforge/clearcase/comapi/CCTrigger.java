/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCTrigger extends ICCTrigger {

	public static final String componentName = "ClearCase.CCTrigger";

	public CCTrigger() {
		super(componentName);
	}

	public CCTrigger(Dispatch d) {
		super(d);
	}
}
