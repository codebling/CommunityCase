/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCVersion extends ICCVersion {

	public static final String componentName = "ClearCase.CCVersion";

	public CCVersion() {
		super(componentName);
	}

	public CCVersion(Dispatch d) {
		super(d);
	}
}
