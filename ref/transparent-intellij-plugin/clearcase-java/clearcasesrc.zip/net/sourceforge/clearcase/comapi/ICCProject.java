/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

public class ICCProject extends Dispatch {

	public static final String componentName = "ClearCase.ICCProject";

	public ICCProject() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public ICCProject(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public ICCProject(String compName) {
		super(compName);
	}

	public ICCAttribute getAttribute(String lastParam) {
		return new ICCAttribute(Dispatch.call(this, "Attribute", lastParam).toDispatch());
	}

	public ICCAttributes getAttributes() {
		return new ICCAttributes(Dispatch.get(this, "Attributes").toDispatch());
	}

	public String getComment() {
		return Dispatch.get(this, "Comment").toString();
	}

	public void setComment(String lastParam) {
		Dispatch.put(this, "Comment", lastParam);
	}

	public ICCHistoryRecord getCreationRecord() {
		return new ICCHistoryRecord(Dispatch.get(this, "CreationRecord").toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor, boolean excludeCheckOutEvents, boolean recurse, boolean lastParam) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor), new Variant(excludeCheckOutEvents), new Variant(recurse), new Variant(lastParam)).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor, boolean excludeCheckOutEvents, boolean recurse) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor), new Variant(excludeCheckOutEvents), new Variant(recurse)).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor, boolean excludeCheckOutEvents) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor), new Variant(excludeCheckOutEvents)).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor)).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since)).toDispatch());
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType).toDispatch());
	}

	public ICCHyperlinks getHyperlinks(String lastParam) {
		return new ICCHyperlinks(Dispatch.call(this, "Hyperlinks", lastParam).toDispatch());
	}

	public ICCHyperlinks getHyperlinks() {
		return new ICCHyperlinks(Dispatch.get(this, "Hyperlinks").toDispatch());
	}

	public String getOID() {
		return Dispatch.get(this, "OID").toString();
	}

	public String getVOBFamilyUUID() {
		return Dispatch.get(this, "VOBFamilyUUID").toString();
	}

	public String getName() {
		return Dispatch.get(this, "Name").toString();
	}

	public void createLock(String comment, boolean obsolete, Variant lastParam) {
		Dispatch.call(this, "CreateLock", comment, new Variant(obsolete), lastParam);
	}

	public void createLock(String comment, boolean obsolete) {
		Dispatch.call(this, "CreateLock", comment, new Variant(obsolete));
	}

	public void createLock(String comment) {
		Dispatch.call(this, "CreateLock", comment);
	}

	public void createLock() {
		Dispatch.call(this, "CreateLock");
	}

	public String getGroup() {
		return Dispatch.get(this, "Group").toString();
	}

	public ICCLock getLock() {
		return new ICCLock(Dispatch.get(this, "Lock").toDispatch());
	}

	public String getMaster() {
		return Dispatch.get(this, "Master").toString();
	}

	public String getOwner() {
		return Dispatch.get(this, "Owner").toString();
	}

	public ICCProjectVOB getProjectVOB() {
		return new ICCProjectVOB(Dispatch.get(this, "ProjectVOB").toDispatch());
	}

	public void setGroup(String newGroup, String lastParam) {
		Dispatch.call(this, "SetGroup", newGroup, lastParam);
	}

	public void setGroup(String newGroup) {
		Dispatch.call(this, "SetGroup", newGroup);
	}

	public void setMaster(String replica, String lastParam) {
		Dispatch.call(this, "SetMaster", replica, lastParam);
	}

	public void setMaster(String replica) {
		Dispatch.call(this, "SetMaster", replica);
	}

	public void setOwner(String newOwner, String lastParam) {
		Dispatch.call(this, "SetOwner", newOwner, lastParam);
	}

	public void setOwner(String newOwner) {
		Dispatch.call(this, "SetOwner", newOwner);
	}

	public String getTitle() {
		return Dispatch.get(this, "Title").toString();
	}

	public String getClearQuestDatabaseName() {
		return Dispatch.get(this, "ClearQuestDatabaseName").toString();
	}

	public ICCStreams getDevelopmentStreams(String lastParam) {
		return new ICCStreams(Dispatch.call(this, "DevelopmentStreams", lastParam).toDispatch());
	}

	public ICCStreams getDevelopmentStreams() {
		return new ICCStreams(Dispatch.get(this, "DevelopmentStreams").toDispatch());
	}

	public boolean getHasStreams() {
		return Dispatch.get(this, "HasStreams").toBoolean();
	}

	public ICCStream getIntegrationStream() {
		return new ICCStream(Dispatch.get(this, "IntegrationStream").toDispatch());
	}

	public boolean getIsCRMEnabled() {
		return Dispatch.get(this, "IsCRMEnabled").toBoolean();
	}

	public ICCComponents getModifiableComponents() {
		return new ICCComponents(Dispatch.get(this, "ModifiableComponents").toDispatch());
	}

	public ICCFolder getParentFolder() {
		return new ICCFolder(Dispatch.get(this, "ParentFolder").toDispatch());
	}

	public ICCProjectPolicy getPolicy() {
		return new ICCProjectPolicy(Dispatch.get(this, "Policy").toDispatch());
	}

	public ICCBaselines getRecommendedBaselines() {
		return new ICCBaselines(Dispatch.get(this, "RecommendedBaselines").toDispatch());
	}

	public String getRequiredPromotionLevel() {
		return Dispatch.get(this, "RequiredPromotionLevel").toString();
	}

	public ICCStreams getStreams(String lastParam) {
		return new ICCStreams(Dispatch.call(this, "Streams", lastParam).toDispatch());
	}

	public ICCStreams getStreams() {
		return new ICCStreams(Dispatch.get(this, "Streams").toDispatch());
	}

}
