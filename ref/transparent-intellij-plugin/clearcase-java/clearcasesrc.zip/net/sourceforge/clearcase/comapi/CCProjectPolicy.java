/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCProjectPolicy extends ICCProjectPolicy {

	public static final String componentName = "ClearCase.CCProjectPolicy";

	public CCProjectPolicy() {
		super(componentName);
	}

	public CCProjectPolicy(Dispatch d) {
		super(d);
	}
}
