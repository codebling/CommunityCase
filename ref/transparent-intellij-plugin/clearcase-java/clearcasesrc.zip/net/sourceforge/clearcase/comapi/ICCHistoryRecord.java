/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class ICCHistoryRecord extends Dispatch {

	public static final String componentName = "ClearCase.ICCHistoryRecord";

	public ICCHistoryRecord() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public ICCHistoryRecord(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public ICCHistoryRecord(String compName) {
		super(compName);
	}

	public String getUserLoginName() {
		return Dispatch.get(this, "UserLoginName").toString();
	}

	public String getUserFullName() {
		return Dispatch.get(this, "UserFullName").toString();
	}

	public String getGroup() {
		return Dispatch.get(this, "Group").toString();
	}

	public String getComment() {
		return Dispatch.get(this, "Comment").toString();
	}

	public void setComment(String lastParam) {
		Dispatch.put(this, "Comment", lastParam);
	}

	public String getHost() {
		return Dispatch.get(this, "Host").toString();
	}

	public String getEventKind() {
		return Dispatch.get(this, "EventKind").toString();
	}

	public java.util.Date getDate() {
		return comDateToJavaDate(Dispatch.get(this, "Date").toDate());
	}

	public ICCVOB getVOB() {
		return new ICCVOB(Dispatch.get(this, "VOB").toDispatch());
	}

	static long zoneOffset	= java.util.Calendar.getInstance().get(java.util.Calendar.ZONE_OFFSET);

	static java.util.Date comDateToJavaDate(double comDate) {
		comDate = comDate - 25569D;
		long millis = Math.round(86400000L * comDate) - zoneOffset;

		java.util.Calendar cal = java.util.Calendar.getInstance();
		cal.setTime(new java.util.Date(millis));
		millis -= cal.get(java.util.Calendar.DST_OFFSET);

		return new java.util.Date(millis);
	}

	static double javaDateToComDate(java.util.Date javaDate) {

		java.util.Calendar cal = java.util.Calendar.getInstance();
		cal.setTime(javaDate);
		long gmtOffset = (cal.get(java.util.Calendar.ZONE_OFFSET) + cal.get(java.util.Calendar.DST_OFFSET));

		long millis = javaDate.getTime() + gmtOffset;
		return 25569D+millis/86400000D;
	}

}
