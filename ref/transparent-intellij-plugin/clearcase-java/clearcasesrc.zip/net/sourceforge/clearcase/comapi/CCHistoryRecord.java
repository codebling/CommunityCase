/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCHistoryRecord extends ICCHistoryRecord {

	public static final String componentName = "ClearCase.CCHistoryRecord";

	public CCHistoryRecord() {
		super(componentName);
	}

	public CCHistoryRecord(Dispatch d) {
		super(d);
	}
}
