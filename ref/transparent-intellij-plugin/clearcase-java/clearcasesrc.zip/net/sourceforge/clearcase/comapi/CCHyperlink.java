/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCHyperlink extends ICCHyperlink {

	public static final String componentName = "ClearCase.CCHyperlink";

	public CCHyperlink() {
		super(componentName);
	}

	public CCHyperlink(Dispatch d) {
		super(d);
	}
}
