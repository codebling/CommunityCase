/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCBranchTypes extends ICCBranchTypes {

	public static final String componentName = "ClearCase.CCBranchTypes";

	public CCBranchTypes() {
		super(componentName);
	}

	public CCBranchTypes(Dispatch d) {
		super(d);
	}
}
