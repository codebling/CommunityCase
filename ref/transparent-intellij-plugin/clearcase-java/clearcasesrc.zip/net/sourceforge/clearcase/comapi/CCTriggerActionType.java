/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;


public interface CCTriggerActionType {

	public static final int ccAction_Exec = 0;
	public static final int ccAction_ExecUNIX = 1;
	public static final int ccAction_ExecWin = 2;
	public static final int ccAction_Mklabel = 3;
	public static final int ccAction_Mkattr = 4;
	public static final int ccAction_MkhlinkTo = 5;
	public static final int ccAction_MkhlinkFrom = 6;
}
